
$(document).ready(function() {
    var currentURL = document.URL;
    var lastIndex = currentURL.lastIndexOf("/");
    var nHtml = currentURL.substring(lastIndex + 1);    //place_order.html
    currentPName = nHtml.substr(0, nHtml.indexOf('.')); //place_order
    //var currentPName = $("#currentPName").attr("data-name");

    /*if(localStorage.getItem("userid") == null) {
        window.location.href = "index.html";
    }*/

    $('.navbar-nav').append('<li class="logoutLinkLI" style="width:auto!important;text-align:center !important;margin-right:2%;"> <a href="#" class="logoutLinkTOP pull-right" style="margin-top: 5px;" title="Logout"><i class="fa fa-power-off pull-right" style="font-size: 21px !important;"></i></a> <a href="javascript:;" class="user-profile dropdown-toggle pull-right" data-toggle="dropdown" aria-expanded="false" style="margin-top: 5px;" title="Settings"><i class="fa fa-cog pull-right" style="font-size: 22px !important;"></i></a> <ul class="dropdown-menu dropdown-usermenu pull-right"> <li><a href="profile.html"><i class="fa fa-user pull-right"></i>My Profile</a></li><li><a href="change_password.html"><i class="fa fa-cog pull-right"></i>Change Password</a></li></ul> <a class="user-profile pull-right"> <img src="MyAssets/images/user.png" alt=""> <b><span class="logUserName"><span></b> </a> </li><li role="presentation" class="dropdown offerNotLI"> <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="true"> <i class="fa fa-gift" style="margin-top:5px !important;font-size:20px !important;"></i> <span class="badge bg-green">5</span> </a> <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu"> <li> <a> <span class="message"> Loading, Please wait. . . </span> </a> </li></ul> </li><li role="presentation" class="dropdown nificationLI"> <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="true"> <i class="fa fa-bell"></i> <span class="badge bg-green">7</span> </a> <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu"> <li> <a> <span class="message"> Loading, Please wait. . . </span> </a> </li></ul> </li>');

    //$("#sidebar-menu > .menu_section > .side-menu").append('<li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a> <ul class="nav child_menu"> <li><a href="#">Dashboard</a></li></ul> </li><li><a href="place_order.html"><i class="fa fa-edit"></i>Place Order</a></li><li><a><i class="fa fa-user"></i>My Profile<span class="fa fa-chevron-down"></span></a> <ul class="nav child_menu"> <li><a href="#">View & Edit</a></li></ul> </li><li><a><i class="fa fa-cog"></i>Change Password</a></li><li><a href="logout.html"><i class="fa fa-sign-out"></i>Logout</a> </li>');
    $("#sidebar-menu > .menu_section > .side-menu").append('<li><a href="place_order.html" ><i class="fa fa-edit"></i>Place Order</a></li><li><a href="distributor_map.html"><i class="fa fa-user-plus"></i>Add Distributor</a></li><li><a href="profile.html"><i class="fa fa-user"></i>My Profile</a></li><li><a href="order_details.html"><i class="fa fa-cart-plus" aria-hidden="true" style="font-size:35px !important;"></i>Orders</a></li><li><a href="add_retailer.html"><i class="fa fa-user-plus"></i>Map Retailer</a></li><li><a href="change_password.html"><i class="fa fa-cog"></i>Change Password</a></li><li class="logoutLinkLI"><a href="#"><i class="fa fa-power-off"></i>Logout</a> </li>');
    $(".logUserName").text(localStorage.getItem("LinNm").toUpperCase());

    //logout feedback popup
    $("body").append('<div class="fade modal"aria-hidden=true data-backdrop=static data-keyboard=false id=logoutFeedbkPop role=dialog tabindex=-1><div class="modal-dialog modal-md"><div class=modal-content><div class=modal-header><button class="close popCloseDistr"type=button data-dismiss=modal><span class="d_sN mod_close"aria-hidden=true>×</span></button><h4 class=modal-title id=myModalLabel>Customer Feedback Form</h4></div><div class=modal-body><div class=row><div class="card-box table-responsive x_content"><div class="col-md-8 col-md-offset-2"><label>Contact Person Name <span class=clrRed>*</span></label><div class="form-group1 has-feedback"><input class=form-controls_values1 id=cntctPersNameFdbk name=lorum placeholder="Contact Person Name"></div></div><div class="col-md-8 col-md-offset-2"><label>Mobile Number <span class=clrRed>*</span></label><div class="form-group1 has-feedback"><input class=form-controls_values1 id=mobNoFdbk name=lorum maxlength=15 value="91 - "></div></div><div class="col-md-8 col-md-offset-2"><label>Description</label><div class="form-group1 has-feedback"><textarea class=form-controls_values1 id=descrFdbk maxlength=450 name=lorum placeholder="Type your feedback here (upto 450 Characters)"style=height:125px!important;resize:none;padding-top:10px></textarea></div></div><div class="col-md-8 col-md-offset-2"><label>Your Rating - <span class=ratingNo></span></label><div class=cont><div class=stars><form action=""><input class="star star-5"id=star-5 name=star type=radio><label class="star star-5"for=star-5></label><input class="star star-4"id=star-4 name=star type=radio><label class="star star-4"for=star-4></label><input class="star star-3"id=star-3 name=star type=radio><label class="star star-3"for=star-3></label><input class="star star-2"id=star-2 name=star type=radio><label class="star star-2"for=star-2></label><input class="star star-1"id=star-1 name=star type=radio><label class="star star-1"for=star-1></label></form></div></div></div></div></div></div><div class=modal-footer><button class="CfeedbackButton btn btn-default btn-sm"type=button id=subAndLogoutFdbk>Submit</button> <button class="CfeedbackButton btn btn-default btn-sm"type=button id=clsAndLogoutFdbk>Logout</button></div></div></div></div>');

    //Start of Tawk.to Script
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/57eb6dd71fd15618f0ce1c9c/default';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
    })();
    // End of Tawk.to Script

    $('#logoutFeedbkPop').on('shown.bs.modal', function () {
        $("#cntctPersNameFdbk").focus();
    });

    var readOnlyLengthFdbk = $('#mobNoFdbk').val().length;
    $('#mobNoFdbk').on('keypress, keydown', function(event) {
        var $field = $(this);
        if ((event.which != 37 && (event.which != 39))
            && ((this.selectionStart < readOnlyLengthFdbk)
            || ((this.selectionStart == readOnlyLengthFdbk) && (event.which == 8)))) {
            return false;
        }
    }); 
    $("#mobNoFdbk").keypress(function (e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            MyError_msg(); $('.errorMsg').text('Please enter numerics only');
            $('#mobNoFdbk').focus();
            return false;
        }
    });
    $(document).on("click",".side-menu > .logoutLinkLI > a, .navbar-right > .logoutLinkLI > .logoutLinkTOP",function(){
        if(localStorage.getItem("logoutFlag") == "true") {
            $('#logoutFeedbkPop').modal("show");
        } else {
            window.location.href = "logout.html";
        }
    });
    $(document).on("click",".stars input.star",function(){
        $(".ratingNo").text($(this).attr("id").split("-")[1]);
    });
    $(document).on("click",".CfeedbackButton",function(){
        if($(this).attr("id") == "subAndLogoutFdbk") {
            if($("#cntctPersNameFdbk").val()) {
                if($("#mobNoFdbk").val().length > 5) {
                    if($("#mobNoFdbk").val().length == 15){
                        if(/^(91(\s*[\ -]\s*)?|[0]?)?[789]\d{9}$/.test($("#mobNoFdbk").val())){
                            if($(".ratingNo").text()) {
                                $(".CfeedbackButton").attr("disabled","true");
                                $.ajax({
                                    data: {usr_id : localStorage.getItem("userid"),cnt_person_name : $("#cntctPersNameFdbk").val(),mob_num : mobNoFun_($("#mobNoFdbk").val()),f_descr : $("#descrFdbk").val(),rating:$(".ratingNo").text()},
                                    url : 'http://'+ip+'/ThillaisServices/rest/web/WANT_FEEDBACK',
                                    type : 'POST',
                                    dataType: 'json',
                                    success: function(data) {
                                        if(data && data.length != 0){
                                            if(data.r == "s") {
                                                alert("Dear customer, Thank you for giving your feedback!!,  Click OK to Logout")
                                                window.location.href = "logout.html";
                                            } else {
                                                MyError_msg();$('.errorMsg').text("Dear Customer, Failed to send feedback, Please try after sometime");
                                            }
                                        } else {
                                            MyError_msg();$('.errorMsg').text("Dear Customer, Failed to send feedback, Please try after sometime");
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        MyError_msg();$('.errorMsg').text(serverBusyError);
                                    }
                                });
                            } else {
                                MyError_msg(); $('.errorMsg').text('Please choose your rating');
                            }
                        } else {
                            $("#mobNoFdbk").focus();
                            MyError_msg(); $('.errorMsg').text('Please enter Mobile No Starting with 7 or 8 or 9');
                        }
                    } else {
                        MyError_msg();$('.errorMsg').text("Mobile Number should be 10 digits, Please enter 10 digits Mobile Number");
                        $("#mobNoFdbk").focus();
                    }
                } else {
                    var SearchInput = $('#mobNoFdbk');
                    SearchInput.val(SearchInput.val());
                    SearchInput.focus();
                    MyError_msg();  
                    $('.errorMsg').text('Please enter Mobile Number');
                }
            } else {
                $("#cntctPersNameFdbk").focus()
                MyError_msg();$('.errorMsg').text("Please enter Contact person name");
            }
        } else if($(this).attr("id") == "clsAndLogoutFdbk") {
            window.location.href = "logout.html";
        }
    });

    // custom.js - code adedd here
    // Sidebar
    $BODY=$("body"),$MENU_TOGGLE=$("#menu_toggle"),$SIDEBAR_MENU=$("#sidebar-menu"),$SIDEBAR_FOOTER=$(".sidebar-footer"),$LEFT_COL=$(".left_col"),$RIGHT_COL=$(".right_col"),$NAV_MENU=$(".nav_menu"),$FOOTER=$("footer");var setContentHeight=function(){$RIGHT_COL.css("min-height",$(window).height());var e=$BODY.outerHeight(),i=$BODY.hasClass("footer_fixed")?0:$FOOTER.height(),t=$LEFT_COL.eq(1).height()+$SIDEBAR_FOOTER.height(),s=t>e?t:e;s-=$NAV_MENU.height()+i,$RIGHT_COL.css("min-height",s)};$SIDEBAR_MENU.find("a").on("click",function(e){var i=$(this).parent();i.is(".active")?(i.removeClass("active active-sm"),$("ul:first",i).slideUp(function(){setContentHeight()})):(i.parent().is(".child_menu")||($SIDEBAR_MENU.find("li").removeClass("active active-sm"),$SIDEBAR_MENU.find("li ul").slideUp()),i.addClass("active"),$("ul:first",i).slideDown(function(){setContentHeight()}))}),$MENU_TOGGLE.on("click",function(){$BODY.hasClass("nav-md")?($SIDEBAR_MENU.find("li.active ul").hide(),$SIDEBAR_MENU.find("li.active").addClass("active-sm").removeClass("active")):($SIDEBAR_MENU.find("li.active-sm ul").show(),$SIDEBAR_MENU.find("li.active-sm").addClass("active").removeClass("active-sm")),$BODY.toggleClass("nav-md nav-sm"),setContentHeight()}),$(window).smartresize(function(){setContentHeight()}),setContentHeight(),$.fn.mCustomScrollbar&&$(".menu_fixed").mCustomScrollbar({autoHideScrollbar:!0,theme:"minimal",mouseWheel:{preventDefault:!0}});
    //Sidebar
    if(localStorage.getItem("flashMsg")){
        MySuccess_msg();
        $('.successMsg').text(localStorage.getItem("flashMsg"));
        localStorage.setItem("flashMsg", '');
    }
    if(localStorage.getItem("userRole") == "9"){
        $('.menu_section > ul > li:nth-child(2)').hide();
        $('.menu_section > ul > li:nth-child(3)').hide();
        $('.dropdown-usermenu > li:nth-child(1)').hide();
        $('.menu_section > ul > li:nth-child(4)').hide();
        $('.menu_section > ul > li:nth-child(5)').hide();
        $("#distributorsInput").hide();
        //$("#reorderBtn").hide();
        $("#PriorityTab").hide();
        if(currentPName == "retailer_profile") {
            window.location.href = "place_order.html";
        }
    } else if(localStorage.getItem("userRole") == "10"){
        $('.menu_section > ul > li:nth-child(4)').hide();
        $('.menu_section > ul > li:nth-child(5)').hide();
    } else if(localStorage.getItem("userRole") == "1"){
        $('.menu_section > ul > li:nth-child(1)').hide();
        $('.menu_section > ul > li:nth-child(2)').hide();
        $('.menu_section > ul > li:nth-child(3)').hide();
        $('.menu_section > ul > li:nth-child(5)').hide();
        $('.dropdown-usermenu > li:nth-child(1)').hide();
    }
    //autocomplete hidden inputs emty
    $(document).on("keyup", 'input', function(event) {
        if($(this).attr("autocomplete")) {
            event.preventDefault();
            if($(this).attr('original_name') != $(this).val()) {
                $(this).prev().val('');
                $(this).prev().attr('original_hidden','');
                $(this).attr('original_name','');
            }
        }
    });
    function stockNearAvail(stock){
        var next = 0;
        if(stock > 0){
            if(stock < 10){
              next = Math.ceil(stock/10) * 10;
              next = "<span style='color:red'>"+"< "+next+"</span>";
              return next;
            } else if(stock < 51){
              next = Math.ceil(stock/50) * 50;
              next = "<span style='color:orange'>"+"< "+next+"</span>";
              return next;
            } else if(stock < 101 && stock > 50){
              next = Math.ceil(stock/50) * 50;
              return "< "+next;
            }
            if(stock == next){
              next = "< "+next + 50;
              return "< "+next;
            }
            if(stock > 100){
              next = "<span style='color:green'>"+"> "+(100)+"</span>";
              return next;
            }
        } else {
            next = "N/A";
            return next;
        }
    }
    if($(window).width() < 755){
        $("body").removeClass("nav-sm").addClass("nav-md");
    }
    if(currentPName == "place_order"){
        $('.menu_section > ul > li:nth-child(1)').css("pointer-events","none");

        //$('.overlay_load').fadeOut();
        $('#fromToDate').daterangepicker({
            startDate: moment().subtract(0, 'days'),
            endDate: moment(),
            /*minDate: '01/01/2012',*/
            maxDate: moment(),
            dateLimit: {
                days: 60
            },
            showDropdowns: false,
            showWeekNumbers: false,
            timePicker: false,
            timePickerIncrement: 1,
            timePicker12Hour: false,
            ranges: {
                'Today': [moment(), moment()],
                'Today, Yesterday': [moment().subtract(1, 'days'), moment()],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                /*'This Month': [moment().startOf('month'), moment().endOf('month')],*/
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            buttonClasses: ['btn btn-default'],
            applyClass: 'btn-small btn-primary',
            cancelClass: 'btn-small',
            locale: {
                format: 'YYYY-MM-DD',
                separator: " To ",
                applyLabel: 'Submit',
                /*fromLabel: 'From',
                toLabel: 'To',*/
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                firstDay: 1
            }
        });
        /*$("#retailerInput").tooltip({
            disabled: true
        }).on("focusin", function () {
            $(this)
                .tooltip("enable")
                .tooltip("open");
        }).on("focusout", function () {
            $(this)
                .tooltip("close")
                .tooltip("disable");
        });*/

        //var pa_ = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd")};
        /*$('#distributorsInput').multiselect({
            buttonWidth: '100%'
        });*/
        function countService(){
            $.ajax({
                data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd")},
                url : 'http://'+ip+'/ThillaisServices/rest/so/GetOrdersCountAmountScore',
                type : 'POST',
                dataType: 'json',
                success: function(data) {
                    if(data){
                        if(data.B == "") {
                            data.B = "0";
                        }
                        if(data.C == "") {
                            data.C = "0";
                        }
                        if(data.D == "") {
                            data.D = "0";
                        }
                        $(".toOrders").text(data.B);
                        $(".totAmount").text(data.C);
                        $(".wScore").text(data.D);
                    }
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                }
            });
        }
        (function($){
            $('#sample-01').plainModal(orderPageNewPopup);
            $("#orderPagePopTxt1").text(orderPagePopUpTxt1);
            $("#orderPagePopTxt2").text(orderPagePopUpTxt2);
            if(localStorage.getItem("userRole") == "9"){
                $("#retailerInput, #retailerSearch").attr("placeholder","Type 2 letters to search")
                $('.overlay_load').fadeOut();
                var retailerAutocmpltLimit = 15;
                localStorage.setItem("sesondServiceCalling",false);
                var avlTagsRetailers = [];
                $(document).on("focus",".retailerInputClass",function(){
                    var thID = $(this).attr("id");
                    $(".retailerInputClass").autocomplete({
                        minLength: 2,
                        source: function( request, response ) {
                            var param = "";input_ = $("#"+thID).val();avlTagsRetailers = [];
                            if(localStorage.getItem("sesondServiceCalling") == 'true') {
                                //alert(localStorage.getItem("sesondServiceParam"));
                                param = JSON.parse(localStorage.getItem("sesondServiceParam"));
                                localStorage.setItem("sesondServiceCalling",false);
                                localStorage.setItem('First','second');
                            } else if(localStorage.getItem("sesondServiceCalling") == 'false') {
                                param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),entityDescr:input_,status:""};
                                localStorage.setItem('First','first');
                            }
                            $.ajax({
                                url: 'http://'+ip+'/ThillaisServices/rest/so/WnSalesPersonAccess',
                                dataType: "json",
                                type:"POST",
                                data: param,
                                success: function(data) {
                                    if(data.length != 0) {
                                        $.each(data, function(index, element) {
                                            if(element.c) {
                                                avlTagsRetailers.push({
                                                    //label: element.entityDescr.trim(),
                                                    value: element.c,
                                                    label: element.c.trim()+', '+element.b.trim(),
                                                    retName : element.b.trim(),
                                                    address :element.d.trim()
                                                });
                                            }
                                        });
                                        if(localStorage.getItem('First') == 'first') {
                                            localStorage.setItem("firstResponse",JSON.stringify(avlTagsRetailers));
                                            retailerAutocmpltLimit = 15;
                                        }
                                        if(localStorage.getItem("inputText") == input_) {
                                            localStorage.setItem("inputText","");
                                            productAutocmpltLimit = 10000000;
                                            var session_data_array = localStorage.getItem("firstResponse");
                                            var data = JSON.parse(session_data_array);
                                            $.each(data, function(index, element) {
                                                avlTagsRetailers.push({
                                                    label: element.label,
                                                    retName : element.retName,
                                                    value: element.value,
                                                    address : element.address
                                                });
                                            });
                                        }
                                    }  
                                    response(avlTagsRetailers.slice(0, retailerAutocmpltLimit));      
                                },
                                error: function(xhr, status, error) {
                                    MyError_msg(); $('.errorMsg').text(serverBusyError);
                                }
                            });
                        },
                        open: function (event, ui) {
                            event.preventDefault();
                            if($(this).attr("id") == "retailerInput" || $(this).attr("id") == "retailerSearch") {
                                var len = avlTagsRetailers.length;
                                if(len == 15) {
                                    $('.ui-autocomplete').append('<li><a class="mcacAnchor c_pointer"><button type="button" class="btn btn-sm btn-default viewMoreLink_'+$(this).attr("id")+'"> View More</button></a></li>');
                                    //$('.autocomplete-suggestions').append('<div class="text-right"><button type="button" class="btn btn-sm btn-default viewMoreLink_'+$(this).attr("id")+'"> View More</button></div>');
                                } else {
                                    
                                }
                            }
                        },
                        focus : function(event,ui) {
                            event.preventDefault();
                        },
                        select: function (event, ui) {
                            event.preventDefault();
                            $("#distributorsInput").show();
                            if($(this).attr("id") == "retailerInput") {
                                $(this).prev().val(ui.item.value);
                                $(this).val(ui.item.retName);
                                $(this).prev().attr('original_hidden',ui.item.value);
                                $(this).attr('original_name',ui.item.retName);
                            } else {
                                $("#distributorsInput").show();
                                $(".retailerInputClass").prev().val(ui.item.value);
                                $(".retailerInputClass").val(ui.item.retName);
                                $(".retailerInputClass").prev().attr('original_hidden',ui.item.value);
                                $(".retailerInputClass").attr('original_name',ui.item.retName);
                            }

                            $(".retaiNameSpan").text(ui.item.retName);
                            $(".retAddsSpan").text(ui.item.address);

                            $(".soIdSearchDIV").slideUp();
                            divTablesEMPTY();
                            //for getting vendors/distributors list
                            var ajxRES = ajxLoadFun(
                                    {userid : localStorage.getItem("userid"),userRole:localStorage.getItem("userRole"),c_code_short:ui.item.value},
                                    "ThillaisServices/rest/req/getWebUserDistributorDtl",
                                    "false"
                                ); 
                            if(ajxRES == "error") {
                                MyError_msg();$('.errorMsg').text(serverBusyError);
                                $('.overlay_load').fadeOut();
                            } else {
                                var reqDis = JSON.parse(ajxRES);
                                if(reqDis && reqDis.length != 0){
                                    var opt = ""; vendorTagsPageLevel = [];
                                    $.each(reqDis, function(index, element) {
                                        var o_rder = "";dis = "";
                                        if(element.k == "false") {
                                            o_rder = "  -  Order Not Allowed";
                                            dis = 'disabled="disabled"';
                                        }
                                        opt += '<option value="'+element.b+'" '+dis+'>'+element.a+o_rder+'</option>';
                                        vendorTagsPageLevel.push({
                                            value: element.b,
                                            label: element.a,
                                            OfferFlag : element.d,
                                            StockFlag : element.e,
                                            MrpFlag : element.f,
                                            PriceFlag : element.g,
                                            MfgrFlag : element.h,
                                            minStkflag : element.i,
                                            BothStockFlag : element.j,
                                            orderFlag : element.k
                                        });
                                    });
                                    if(vendorTagsPageLevel.length == 1){
                                        if($(this).attr("id") == "retailerSearch") {
                                            $('#disrbtrSearchHidden').val(vendorTagsPageLevel[0].value);
                                            $('#distributorSearch').val(vendorTagsPageLevel[0].label);
                                            $('#disrbtrSearchHidden').attr('original_hidden',vendorTagsPageLevel[0].value);
                                            $('#distributorSearch').attr('original_name',vendorTagsPageLevel[0].label);
                                            $('#disrbtrSearchHidden').attr('StockFlag',vendorTagsPageLevel[0].StockFlag);
                                            $('#disrbtrSearchHidden').attr('MrpFlag',vendorTagsPageLevel[0].MrpFlag);
                                            $('#distributorSearch').attr('PriceFlag',vendorTagsPageLevel[0].PriceFlag);
                                            $('#disrbtrSearchHidden').attr('OfferFlag',vendorTagsPageLevel[0].OfferFlag);
                                            $('#disrbtrSearchHidden').attr('MfgrFlag',vendorTagsPageLevel[0].MfgrFlag);
                                            $('#disrbtrSearchHidden').attr('minStkflag',vendorTagsPageLevel[0].minStkflag);
                                            $('#disrbtrSearchHidden').attr('BothStockFlag',vendorTagsPageLevel[0].BothStockFlag);
                                            $(".soIdSearchDIV").slideUp();
                                        }
                                    }
                                    //if($(this).attr("id") == "retailerInput") {
                                        $(".distributorsInputDIV").html('<select id="distributorsInput" multiple="multiple" class="form-control testSelAll"></select>');

                                        $('#distributorsInput').html(opt);
                                        window.testSelAll = $('.testSelAll').SumoSelect({
                                            selectAll:true,
                                            searchText:'Enter here.', 
                                            up:false, 
                                            search:true,
                                            placeholder: 'Select Distributor(s)',
                                            //okCancelInMulti:true,
                                            triggerChangeCombined:true
                                        });
                                        if($('.optWrapper > .select-all',$("#distributorsInput").parent()).hasClass("selected")) {

                                        } else {
                                            $('.optWrapper > .select-all',$("#distributorsInput").parent()).click();
                                        }
                                        $(".mySPANsiva",$("#distributorsInput").next()).click();
                                        
                                        //$('.optWrapper > .select-all',$("#distributorsInput").parent()).addClass("selected");
                                        $('.optWrapper > ul > li',$("#distributorsInput").parent()).each(function(){
                                            var thVal = $(this).attr("data-val");
                                            var $thsLI = $(this);
                                            //$thsLI.click();
                                            $.each(vendorTagsPageLevel, function(index, element) {
                                                if(element.value == thVal) {
                                                    $thsLI.attr("data-OfferFlag",element.OfferFlag);
                                                    $thsLI.attr("data-StockFlag",element.StockFlag);
                                                    $thsLI.attr("data-MrpFlag",element.MrpFlag);
                                                    $thsLI.attr("data-PriceFlag",element.PriceFlag);
                                                    $thsLI.attr("data-MfgrFlag",element.MfgrFlag);
                                                    $thsLI.attr("data-minStkflag",element.minStkflag);
                                                    $thsLI.attr("BothStockFlag",element.BothStockFlag);
                                                }
                                            });
                                        });
                                        continueFUN();
                                        liClickFun();
                                    //}
                                    $('.overlay_load').fadeOut();
                                    $("#distributorSearch").autocomplete({
                                        source: vendorTagsPageLevel,
                                        focus : function(event,ui) {
                                            event.preventDefault();
                                        },
                                        select: function (event, ui) {
                                            event.preventDefault();
                                            $("#plcOrderBTN").focus();
                                            $('#distributorSearch').val(ui.item.label);
                                            $('#disrbtrSearchHidden').attr('original_hidden',ui.item.value);
                                            $('#disrbtrSearchHidden').val(ui.item.value);
                                            $('#distributorSearch').attr('original_name',ui.item.label);
                                            $('#distributorSearch').attr('StockFlag',ui.item.StockFlag);
                                            $('#distributorSearch').attr('MrpFlag',ui.item.MrpFlag);
                                            $('#distributorSearch').attr('PriceFlag',ui.item.PriceFlag);
                                            $('#distributorSearch').attr('OfferFlag',ui.item.OfferFlag);
                                            $('#distributorSearch').attr('MfgrFlag',ui.item.MfgrFlag);
                                            $('#distributorSearch').attr('minStkflag',ui.item.minStkflag);
                                            $('#distributorSearch').attr('BothStockFlag',ui.item.BothStockFlag);
                                        }
                                    });
                                } else {
                                    MyError_msg();$('.errorMsg').text("Sorry, Distributors not available for this retailer");
                                    $('.overlay_load').fadeOut();
                                } 
                            }      
                        }
                    });
                });
                $(document).on('click','.viewMoreLink_retailerInput, .viewMoreLink_retailerSearch',function(){
                    retailerAutocmpltLimit = 10000000;
                    var inputText = "";inputAuto = "";
                    if($(this).hasClass('viewMoreLink_retailerInput')) {
                        inputAuto = $('#retailerInput');
                        var inputText = $("#retailerInput").val();
                    } else if($(this).hasClass('viewMoreLink_retailerSearch')) {
                        inputAuto = $('#retailerSearch');
                        var inputText = $("#retailerSearch").val();
                    }
                    var param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),entityDescr:inputText,status:inputText};
                    localStorage.setItem("sesondServiceCalling",true);
                    localStorage.setItem("sesondServiceParam",JSON.stringify(param));
                    localStorage.setItem("inputText",inputText);
                    inputAuto.val(inputText);
                    inputAuto.autocomplete('search',inputText);
                });
            } else {
                $.ajax({
                    data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd")},
                    url : 'http://'+ip+'/ThillaisServices/rest/req/getWebUserEntity',
                    type : 'POST',
                    dataType: 'json',
                    success: function(reqRetailer) {
                        if(reqRetailer){
                            //var reqRetailer = JSON.parse(ajxRES);
                            if(reqRetailer != null && reqRetailer.length != 0) {
                                var availableTags = [];
                                $.each(reqRetailer, function(index, element) {
                                    if(element.a) {
                                        availableTags.push({
                                            label: element.b.trim()+", "+element.c.trim(),
                                            value: element.a,
                                            retName: element.b.trim(),
                                            address: element.c.trim()
                                        });
                                    }
                                }); 
                                if(availableTags.length == 1){
                                    $(".retaiNameSpan").text(availableTags[0].retName);
                                    $(".retAddsSpan").text(availableTags[0].address);
                                    $('#retailerAddHidden').val(availableTags[0].value);
                                    $('#retailerInput').val(availableTags[0].retName);
                                    $('#retailerAddHidden').attr('original_hidden',availableTags[0].value);
                                    $('#retailerInput').attr('original_name',availableTags[0].retName);
                                    $('#retailerSearchHidden').val(availableTags[0].value);
                                    $('#retailerSearch').val(availableTags[0].retName);
                                    $('#retailerSearchHidden').attr('original_hidden',availableTags[0].label);
                                    $('#retailerSearch').attr('original_name',availableTags[0].value);
                                    //for getting vendors/distributors list
                                    var ajxRES = ajxLoadFun(
                                            {userid : localStorage.getItem("userid"),userRole:localStorage.getItem("userRole"),c_code_short:availableTags[0].value},
                                            "ThillaisServices/rest/req/getWebUserDistributorDtl",
                                            "false"
                                        ); 
                                    if(ajxRES == "error") {
                                        MyError_msg();$('.errorMsg').text(serverBusyError);
                                        $('.overlay_load').fadeOut();
                                    } else {
                                        var reqDis = JSON.parse(ajxRES);
                                        if(reqDis && reqDis.length != 0){
                                        var opt = ""; disableOPT = ""; vendorTagsPageLevel = [];
                                            $.each(reqDis, function(index, element) {
                                                var o_rder = "";dis = "";
                                                if(element.k == "false") {
                                                    o_rder = "  -  Order Not Allowed";
                                                    dis = 'disabled="disabled"';
                                                    disableOPT += '<option value="'+element.b+'" '+dis+'>'+element.a+o_rder+'</option>';
                                                } else if(element.k == "true" || element.k == "") {
                                                    vendorTagsPageLevel.push({
                                                        value: element.b,
                                                        label: element.a,
                                                        OfferFlag : element.d,
                                                        StockFlag : element.e,
                                                        MrpFlag : element.f,
                                                        PriceFlag : element.g,
                                                        MfgrFlag : element.h,
                                                        minStkflag : element.i,
                                                        BothStockFlag : element.j,
                                                        orderFlag : element.k,
                                                        limitFlag : element.m
                                                    });
                                                    opt += '<option value="'+element.b+'" '+dis+'>'+element.a+o_rder+'</option>';
                                                }
                                            });
                                            $(".distributorsInputDIV").html('<select id="distributorsInput" multiple="multiple" class="form-control testSelAll"></select>');
                                            
                                            $('#distributorsInput').html(opt);
                                            $('#distributorsInput').append(disableOPT);
                                            window.testSelAll = $('.testSelAll').SumoSelect({
                                                selectAll:true,
                                                searchText:'Enter here.', 
                                                up:false, 
                                                search:true,
                                                placeholder: 'Select Distributor(s)',
                                                triggerChangeCombined:true
                                            });
                                            $('.optWrapper > .select-all',$("#distributorsInput").parent()).click();
                                            $(".mySPANsiva",$("#distributorsInput").next()).click();
                                            $('.optWrapper > ul > li',$("#distributorsInput").parent()).each(function(){
                                                var thVal = $(this).attr("data-val");
                                                var $thsLI = $(this);
                                                //$thsLI.click();
                                                $.each(vendorTagsPageLevel, function(index, element) {
                                                    if(element.value == thVal) {
                                                        $thsLI.attr("data-OfferFlag",element.OfferFlag);
                                                        $thsLI.attr("data-StockFlag",element.StockFlag);
                                                        $thsLI.attr("data-MrpFlag",element.MrpFlag);
                                                        $thsLI.attr("data-PriceFlag",element.PriceFlag);
                                                        $thsLI.attr("data-MfgrFlag",element.MfgrFlag);
                                                        $thsLI.attr("data-minStkflag",element.minStkflag);
                                                        $thsLI.attr("BothStockFlag",element.BothStockFlag);
                                                        $thsLI.attr("limitFlag",element.limitFlag);
                                                    }

                                                });
                                            });
                                            continueFUN();
                                            //$(".btnOk",$("#distributorsInput").parent()).click();

                                            if(vendorTagsPageLevel.length == 1){
                                                $('#disrbtrSearchHidden').val(vendorTagsPageLevel[0].value);
                                                $('#distributorSearch').val(vendorTagsPageLevel[0].label);
                                                $('#disrbtrSearchHidden').attr('original_hidden',vendorTagsPageLevel[0].value);
                                                $('#distributorSearch').attr('original_name',vendorTagsPageLevel[0].label);
                                                $('#distributorSearch').attr('StockFlag',vendorTagsPageLevel[0].StockFlag);
                                                $('#distributorSearch').attr('MrpFlag',vendorTagsPageLevel[0].MrpFlag);
                                                $('#distributorSearch').attr('PriceFlag',vendorTagsPageLevel[0].PriceFlag);
                                                $('#distributorSearch').attr('OfferFlag',vendorTagsPageLevel[0].OfferFlag);
                                                $('#distributorSearch').attr('MfgrFlag',vendorTagsPageLevel[0].MfgrFlag);
                                                $('#distributorSearch').attr('minStkflag',vendorTagsPageLevel[0].minStkflag);
                                                $('#distributorSearch').attr('BothStockFlag',vendorTagsPageLevel[0].BothStockFlag);
                                                $('#distributorSearch').attr('limitFlag',vendorTagsPageLevel[0].limitFlag);
                                            }
                                            $('.overlay_load').fadeOut();
                                            $("#distributorSearch").autocomplete({
                                                source: vendorTagsPageLevel,
                                                focus : function(event,ui) {
                                                    event.preventDefault();
                                                },
                                                select: function(event,ui){
                                                    event.preventDefault();
                                                    $("#searchBtn").focus();
                                                    $('#distributorSearch').val(ui.item.label);
                                                    $('#disrbtrSearchHidden').attr('original_hidden',ui.item.value);
                                                    $('#disrbtrSearchHidden').val(ui.item.value);
                                                    $('#distributorSearch').attr('original_name',ui.item.label);
                                                    $('#distributorSearch').attr('StockFlag',ui.item.StockFlag);
                                                    $('#distributorSearch').attr('MrpFlag',ui.item.MrpFlag);
                                                    $('#distributorSearch').attr('PriceFlag',ui.item.PriceFlag);
                                                    $('#distributorSearch').attr('OfferFlag',ui.item.OfferFlag);
                                                    $('#distributorSearch').attr('MfgrFlag',ui.item.MfgrFlag);
                                                    $('#distributorSearch').attr('minStkflag',ui.item.minStkflag);
                                                    $('#distributorSearch').attr('BothStockFlag',ui.item.BothStockFlag);
                                                    $('#distributorSearch').attr('limitFlag',ui.item.limitFlag);
                                                    $(".soIdSearchDIV").slideUp();
                                                }
                                            }).bind('focus', function(){ $(this).autocomplete("search"," "); } );
                                                $('#distributorSearch').focus();
                                        } else {
                                            MyError_msg();$('.errorMsg').text("Sorry, Distributors not available for this retailer");
                                            $('.overlay_load').fadeOut();
                                        } 
                                        $("#productsSearch").focus();
                                    }          
                                } else {
                                    //$("#reorderBtn").hide();
                                    $('.overlay_load').fadeOut();
                                }
                                //search and add entity autocompletes
                                $(document).on("focus", ".retailerInputClass", function(event) {
                                    var inputID = $(this).attr("id");
                                    $('.retailerInputClass').autocomplete({
                                        source: availableTags,
                                        focus : function(event,ui) {
                                            event.preventDefault();
                                        },
                                        select : function(event,ui) {
                                            event.preventDefault();
                                            $(".retaiNameSpan").text(ui.item.retName);
                                            $(".retAddsSpan").text(ui.item.address);
                                            if($(this).attr("id") == "retailerInput") {
                                                $(this).prev().val(ui.item.value);
                                                $(this).val(ui.item.retName);
                                                $(this).prev().attr('original_hidden',ui.item.value);
                                                $(this).attr('original_name',ui.item.retName);
                                            } else {
                                                $("#distributorsInput").show();
                                                $(".retailerInputClass").prev().val(ui.item.value);
                                                $(".retailerInputClass").val(ui.item.retName);
                                                $(".retailerInputClass").prev().attr('original_hidden',ui.item.value);
                                                $(".retailerInputClass").attr('original_name',ui.item.retName);
                                            }
                                            $(".soIdSearchDIV").slideUp();
                                            divTablesEMPTY();
                                            var ajxRES = ajxLoadFun(
                                                    {userid : localStorage.getItem("userid"),userRole:localStorage.getItem("userRole"),c_code_short:$(this).prev().val()},
                                                    "ThillaisServices/rest/req/getWebUserDistributorDtl",
                                                    "false"
                                                ); 
                                            if(ajxRES == "error") {
                                                MyError_msg();$('.errorMsg').text(serverBusyError);
                                                $('.overlay_load').fadeOut();
                                            } else {
                                                var reqDis = JSON.parse(ajxRES);
                                                if(reqDis && reqDis.length != 0){
                                                    var opt = "";disableOPT=""; vendorTagsPageLevel = [];
                                                    $.each(reqDis, function(index, element) {
                                                        var o_rder = "";dis = "";
                                                        if(element.k == "false") {
                                                            o_rder = "  -  Order Not Allowed";
                                                            dis = 'disabled="disabled"';
                                                            disableOPT += '<option value="'+element.b+'" '+dis+'>'+element.a+o_rder+'</option>';
                                                        } else if(element.k == "true" || element.k == "") {
                                                            vendorTagsPageLevel.push({
                                                                value: element.b,
                                                                label: element.a,
                                                                OfferFlag : element.d,
                                                                StockFlag : element.e,
                                                                MrpFlag : element.f,
                                                                PriceFlag : element.g,
                                                                MfgrFlag : element.h,
                                                                minStkflag : element.i,
                                                                BothStockFlag : element.j,
                                                                orderFlag : element.k,
                                                                limitFlag : element.m
                                                            });
                                                            opt += '<option value="'+element.b+'" '+dis+'>'+element.a+o_rder+'</option>';
                                                            }
                                                    });
                                                    if(inputID == 'retailerSearch') {
                                                        if(vendorTagsPageLevel.length == 1){
                                                            $('#disrbtrSearchHidden').val(vendorTagsPageLevel[0].label);
                                                            $('#distributorSearch').val(vendorTagsPageLevel[0].value);
                                                            $('#disrbtrSearchHidden').attr('original_hidden',vendorTagsPageLevel[0].label);
                                                            $('#distributorSearch').attr('original_name',vendorTagsPageLevel[0].value);
                                                        }
                                                        $("#distributorSearch").autocomplete({
                                                            source: vendorTagsPageLevel,
                                                            focus : function(event,ui) {
                                                                event.preventDefault();
                                                            },
                                                            select: function(event,ui){
                                                                event.preventDefault();
                                                                $("#searchBtn").focus();
                                                                $('#disrbtrSearchHidden').attr('original_hidden',ui.item.value);
                                                                $('#disrbtrSearchHidden').val(ui.item.value);
                                                                $('#distributorSearch').attr('original_name',ui.item.label);
                                                                $('#distributorSearch').val(ui.item.label);
                                                                $(".soIdSearchDIV").slideUp();
                                                            }
                                                        }).bind('focus', function(){ $(this).autocomplete("search"," "); } );
                                                        $("#distributorSearch").focus();
                                                    }
                                                    //if(inputID == 'retailerInput') {
                                                        $(".distributorsInputDIV").html('<select id="distributorsInput" multiple="multiple" class="form-control testSelAll"></select>');

                                                        var num = $('#distributorsInput option').length;
                                                        for(var i=0; i<num; i++){
                                                            $('.testSelAll')[0].sumo.unSelectItem(i);
                                                        }
                                                        $('#distributorsInput').html(opt);
                                                        $('#distributorsInput').append(disableOPT);
                                                        window.testSelAll = $('.testSelAll').SumoSelect({
                                                            selectAll:true,
                                                            searchText:'Enter here.', 
                                                            up:false, 
                                                            search:true,
                                                            placeholder: 'Select Distributor(s)',
                                                            //okCancelInMulti:true,
                                                            triggerChangeCombined:true
                                                        });
                                                        if($('.optWrapper > .select-all',$("#distributorsInput").parent()).hasClass("selected")) {

                                                        } else {
                                                            $('.optWrapper > .select-all',$("#distributorsInput").parent()).click();
                                                        }
                                                        $(".mySPANsiva",$("#distributorsInput").next()).click();
                                                        //$('.optWrapper > .select-all',$("#distributorsInput").parent()).addClass("selected");
                                                        $('.optWrapper > ul > li',$("#distributorsInput").parent()).each(function(){
                                                            var thVal = $(this).attr("data-val");
                                                            var $thsLI = $(this);
                                                            //$thsLI.click();
                                                            $.each(vendorTagsPageLevel, function(index, element) {
                                                                if(element.value == thVal) {
                                                                    $thsLI.attr("data-OfferFlag",element.OfferFlag);
                                                                    $thsLI.attr("data-StockFlag",element.StockFlag);
                                                                    $thsLI.attr("data-MrpFlag",element.MrpFlag);
                                                                    $thsLI.attr("data-PriceFlag",element.PriceFlag);
                                                                    $thsLI.attr("data-MfgrFlag",element.MfgrFlag);
                                                                    $thsLI.attr("data-minStkflag",element.minStkflag);
                                                                    $thsLI.attr("BothStockFlag",element.BothStockFlag);
                                                                    $thsLI.attr("limitFlag",element.limitFlag);
                                                                }

                                                            });
                                                        });
                                                        continueFUN();
                                                        liClickFun();
                                                        $("#distributorsInput").focus();
                                                    //}
                                                    //$('.overlay_load').fadeOut();
                                                } else {
                                                    MyError_msg();$('.errorMsg').text("Sorry, Distributors not available for this retailer");
                                                    $('.overlay_load').fadeOut();
                                                } 
                                            } 
                                        }
                                    }).bind('focus', function(){ $(this).autocomplete("search"," "); } );
                                });
                                if(availableTags.length > 1){
                                    //$('#retailerInput').focus();
                                }
                            } else {
                                MyError_msg();$('.errorMsg').text("Sorry, You Cannot able to Create Requisition, Please Contact Admin");$('.overlay_load').fadeOut();
                            }
                            liClickFun();
                            countService();
                        }
                    },
                    error: function(xhr, status, error) {
                        MyError_msg();$('.errorMsg').text(serverBusyError);
                    }
                });
            }
        })(jQuery);
        function liClickFun(){
            $(".options",$("#distributorsInput").parent()).find("li").click(function(){
                var distId = $(this).attr('data-val');
                localStorage.setItem("dIDfordel",distId);
                if($("#selectedProducts > tbody > tr").length > 0) {
                    $("#selectedProducts > tbody > tr").each(function(){
                        if(distId == $('.Sparent_vendor',this).val()){
                            $(this).remove();
                            updateSlnoPrdcts();
                        }
                    });
                }
                $("#DistWiseTot > tbody > tr").each(function(){
                    if(distId == $('.disIdDistWiseT',this).val()) {
                        $(this).attr("deleted","true").hide();
                        //$('#DistWiseTot').DataTable().row(this).remove().draw( false );
                    }
                });
                selPrdGrandTOT();
                continueFUN();
            });
        }
        localStorage.removeItem("SDList");
        function continueFUN() {
            var distributorTags = [];vendorsCount = 0;
            $('.optWrapper ul li',$("#distributorsInput").parent()).each(function(){
                if($(this).hasClass('selected')) {
                    vendorsCount++;
                    distributorTags.push({
                        value : $(this).attr("data-val"),
                        vendorName : $(this).text(),
                        OfferFlag : $(this).attr('data-OfferFlag'),
                        stockFlag : $(this).attr('data-StockFlag'),
                        MrpFlag : $(this).attr('data-MrpFlag'),
                        PriceFlag : $(this).attr('data-PriceFlag'),
                        MfgrFlag : $(this).attr('data-MfgrFlag'),
                        minStkflag : $(this).attr('data-minStkflag'),
                        BothStockFlag : $(this).attr('BothStockFlag'),
                        limitFlag : $(this).attr('limitFlag')
                    });
                }
            });
            //console.log(localStorage.getItem("SDList"))
            if(distributorTags.length == 0) {
                $(".distWiseGtotal").text("0.00");
                if(!$('.optWrapper .select-all',$("#distributorsInput").parent()).hasClass('selected')) {
                    //MyError_msg();$('.errorMsg').text("Dear customer, Distributor (s) needed for product selection");             
                }
                localStorage.removeItem("SDList");
                //$('.optWrapper > .select-all',$("#distributorsInput").parent()).click();
                //thBTN.click();
                /*$('.optWrapper p',$("#distributorsInput").parent()).addClass("selected");
                $('.optWrapper ul li',$("#distributorsInput").parent()).each(function(){
                    if($(this).hasClass('disabled')) {
                    } else {
                        $(this).addClass('selected');
                    }
                });*/
                //continueFUN();
            } else {
                localStorage.setItem("SDList",JSON.stringify(distributorTags));
                //console.log($(".options li",$("#distributorsInput").parent()).hasClass("selected").length)
                $('.CaptionCont',$("#distributorsInput").parent()).attr("title",vendorsCount+" Distributor(s) Selected");
                $('.CaptionCont span',$("#distributorsInput").parent()).removeClass("placeholder").text(vendorsCount+" Distributor(s) Selected")
                var dist_ = JSON.parse(localStorage.getItem("SDList"));
                var str = "";sno = 1;
                //console.log(localStorage.getItem("SDList"))
                $.each(dist_,function(ind,ele) {
                    str += "<tr class='d_sN'><td class='distrDesc'><input type='hidden' class='limitSummHidn' value='"+ele.limitFlag+"'><span class='d_sN' style='margin-top:-5px;float: right;color: red;'><i class='fa fa-clock-o' aria-hidden='true' style='vertical-align: middle;'></i></span><input type='hidden' class='disIdDistWiseT' value='"+ele.value+"'>"+ele.vendorName+"</td><td class='prodtsDistWiseT'>0</td><td class='TotDistWiseT'>0.00</td></tr>";
                });
                $("#DistWiseTot > tbody").html(str);
                $("#selectedProducts > tbody > tr").each(function(){
                    var th = $(this);
                    var lineTot = parseFloat($(".lineTotHiddden",this).val());
                    $("#DistWiseTot > tbody > tr").each(function(){
                        if($('.Sparent_vendor',th).val() == $('.disIdDistWiseT',this).val()) {
                            $(this).removeClass("d_sN");
                            $('.prodtsDistWiseT',this).text(parseInt($('.prodtsDistWiseT',this).text())+1);
                            var tableLinesSum = parseFloat($('.TotDistWiseT',this).text());
                            $('.TotDistWiseT',this).text(parseFloat(lineTot+tableLinesSum).toFixed(2));
                        }
                    }); 
                });
            }
        }
        $("#btnAddDummy").click(function(){
            $("#productsSearch").focus();
        });
        function totSeleProdCount() {
            var tot = 0;
            $('#DistWiseTot > tbody > tr').each(function() {
                if($(this).attr("deleted") != "true") {
                    tot += parseInt($(".prodtsDistWiseT",this).text());
                }
            });
            $(".distWiseTotLines").text(tot);
        }
        function updateSlnoPrdcts(){
            var j = $('#selectedProducts > tbody > tr').length;
            $('#selectedProducts > tbody > tr').each(function() {
                $('.num', this).html('<span>'+j+'</span>');
                j--;
            });
        }
        function selPrdGrandTOT() {
            var gtotal = 0;
            $('#selectedProducts > tbody > tr').each(function() {
                if($('.pcode_Hidden',this).val()) {
                    gtotal = +$('.lineTotHiddden', this).val()+gtotal;
                }
            });
            $('.distWiseGtotal').text(parseFloat(gtotal).toFixed(2));
            totSeleProdCount();
        }
        function divTablesEMPTY() {
            //$("#productsDivsHide").slideUp();
            $("#selectedProducts > tbody").html("");
            $("#DistWiseTot > tbody > tr").each(function(){
                $('.prodtsDistWiseT',this).text(0);
                $('.TotDistWiseT',this).text('0.00');
                if(!$(this).hasClass("d_sN")) {
                    $(this).addClass("d_sN")
                }
            });
            $(".distWiseTotLines").text("0");
            $('.distWiseGtotal').text('0.00');
        }
        $(document).on("keyup", '#retailerInput', function(event) {
            event.preventDefault();
            if($(this).attr('original_name') != $(this).val() || $(this).val() == '') {
                $(this).prev().val('');
                $(this).prev().attr('original_hidden','');
                $(this).attr('original_name','');
                divTablesEMPTY();
            }
        });
        $.widget('custom.mcautocomplete', $.ui.autocomplete, {
          minLength: 2,
            _create: function () {
                this._super();
                this.widget().menu("option", "items", "> :not(.ui-widget-header)");
            },
            _renderMenu: function (ul, items) {
                var self = this,
                    thead;
                if (this.options.showHeader) {
                    table = $('<div class="ui-widget-header" style="width:100%"></div>');
                    $.each(this.options.columns, function (index, item) {
                        table.append('<span style="padding:0 4px;float:left;width:' + item.width + ';text-align:'+item.align+'">' + item.name + '</span>');
                    });
                    table.append('<div style="clear: both;"></div>');
                    ul.append(table);
                }
                $.each(items, function (index, item) {
                    self._renderItem(ul, item);
                });
                $('#autocompleteHead').show();
            },
            _renderItem: function (ul, item) {
                var t = '',result = '';
                $.each(this.options.columns, function (index, column) {
                    t += '<span class="productAutoSpanDivider" style="padding:0 4px;float:left;width:' + column.width + ';text-align:'+column.align+'">' + item[column.valueField ? column.valueField : index] + '</span>';
                });
                result = $('<li></li>')
                    .data('ui-autocomplete-item', item)
                    .append('<a class="mcacAnchor permalink_section">' + t + '<div style="clear: both;"></div></a>')
                    .appendTo(ul);
                return result;
            }
        });
        var productAutocmpltLimit = 200;
        localStorage.setItem("sesondServiceCalling",false);
        var prdctAutocomplete = $("#productsSearch").mcautocomplete({
            showHeader: true,
            columns : [{
                name: 'Product',
                width: '31%',
                valueField: 'label',
                align: ''
            }, {
                name: 'Pack',
                width: '8%',
                valueField: 'pack',
                align: 'center'
            }, {
                name: 'Distributor',
                width: '21%',
                valueField: 'vendorShortName',
                align: 'left'
            }, {
                name: 'Stock',
                width: '7%',
                valueField: 'stockDisplay',
                align: 'center'
            },{
                name: 'Offer',
                width: '9%',
                valueField: 'offerDisplay',
                align: 'center'
            },{
                name: 'Mrp',
                width: '8%',
                valueField: 'mrpDisplay',
                align: 'center'
            },{
                name: 'Price',
                width: '8%',
                valueField: 'spDisplay',
                align: 'center'
            },{
                name: 'Manuf',
                width: '8%',
                valueField: 'manufaDisplay',
                align: 'left'
            }],
            minLength: 3,
            source: function( request, response ) {
                if($("#retailerAddHidden").val()){
                    if(localStorage.getItem("SDList")) {
                        var recordsNos = "";input_ = request.term.replace(/ +/g, ' ');
                        //console.log("input_  :"+input_+"  Len: "+input_.length);
                        if(localStorage.getItem("sesondServiceCalling") == 'true') {
                            //param = JSON.parse(localStorage.getItem("sesondServiceParam"));
                            if(localStorage.getItem("inputText") == input_) {
                                recordsNos = parseInt(localStorage.getItem("viewMoreClick"));
                            } else {
                                localStorage.setItem("viewMoreClick",0)
                                recordsNos = parseInt(localStorage.getItem("viewMoreClick",1));
                            }
                            //localStorage.setItem("sesondServiceCalling",false);
                            localStorage.setItem('First','second');
                        } else if(localStorage.getItem("sesondServiceCalling") == 'false') {
                            //param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:localStorage.getItem("entity_id"),Vendor_access_data:JSON.parse(localStorage.getItem("vendor_id")),productdescr:input_,productExtra:""};
                            localStorage.setItem("viewMoreClick",0);
                            recordsNos = parseInt(localStorage.getItem("viewMoreClick"));
                            localStorage.setItem('First','first');
                        }
                        var commaSepVendors = "";
                        $.each(JSON.parse(localStorage.getItem("SDList")), function(index, el) {
                            commaSepVendors += el.value+", ";
                        });
                        $.ajax({
                            url: 'http://'+newAPI_ip+'/oauth/token?grant_type=password&client_id=restapp&client_secret=restapp&username=netmed&password=netmed@123',
                            dataType: "json",
                            type:"GET",
                            async:"false",
                            global:"true",
                            success: function(data) {
                                var param = "http://"+newAPI_ip+"/api/stocks/["+commaSepVendors.slice(0,-2)+']/'+input_+'/'+recordsNos+'/200/p?access_token='+data.access_token;
                                $.ajax({
                                    url: param,
                                    dataType: "json",
                                    type:"GET",
                                    async:"false",
                                    success: function(data) { 
                                        var availableTagsProductSelection = [];
                                        var ij = 0;
                                        if(localStorage.getItem("vMoreIteration")) {
                                            if(localStorage.getItem("inputText") != $("#productsSearch").val()) {
                                                localStorage.setItem("vMoreIteration",0);
                                            }
                                            ij = parseInt(localStorage.getItem("vMoreIteration"));
                                        }
                                        $('.overlay_load').fadeOut();
                                        var stockDisplay = 0;mrpDisplay = "";spDisplay = "";offerDisplay = "";manufaDisplay = "";
                                        if(data.length != 0) {
                                            localStorage.setItem("responseLength",data.length);
                                            $.each(data, function(index, element) {
                                                var thisVenId = element.sParentId;
                                                var thisStock = element.qty;
                                                var reqSelected = localStorage.getItem("SDList");
                                                //console.log(" ele "+element.manufName);
                                                $.each(JSON.parse(reqSelected), function(index, ele) {
                                                    if(thisVenId == ele.value) {
                                                    //console.log("product"+thisVenId+" ele "+ele.vendor_id);
                                                        function flagBased() {
                                                            if (ele.MrpFlag == "true" || ele.MrpFlag == ""){
                                                                if(element.mrp == "" || element.mrp == null) {
                                                                    mrpDisplay = "N/A";
                                                                } else {
                                                                    mrpDisplay = element.mrp;
                                                                }
                                                            } else { 
                                                                mrpDisplay = "A";
                                                            }
                                                            if (ele.PriceFlag == "true" || ele.PriceFlag == "")
                                                                spDisplay = element.rmrp;
                                                            else spDisplay = "A";
                                                            if (ele.OfferFlag == "true" || ele.OfferFlag == "")
                                                                if(element.offer == "" || element.offer == null) {
                                                                    offerDisplay = "N/A";
                                                                } else {
                                                                    offerDisplay = element.offer.trim();
                                                                }
                                                            else offerDisplay = "A";
                                                            if (ele.MfgrFlag == "true" || ele.MfgrFlag == "")
                                                                if(element.manufName == "" || element.manufName == null) {
                                                                    manufaDisplay = "N/A";
                                                                } else {
                                                                    manufaDisplay = element.manufName.trim();
                                                                }
                                                            else manufaDisplay = "A";
                                                        }
                                                        function onlyAvailable(){
                                                            mrpDisplay = "A";
                                                            spDisplay = "A";
                                                            offerDisplay = "A";
                                                            manufaDisplay = "A";
                                                        }
                                                        if(ele.minStkflag == "true"){
                                                            stockDisplay = stockNearAvail(element.qty);
                                                            if(ele.BothStockFlag == "true"){ //less - true, both - true
                                                                flagBased();
                                                            } else {  //less - true, both - false
                                                                onlyAvailable();
                                                            }
                                                        } else {
                                                            stockDisplay = "A";
                                                            if(ele.BothStockFlag == "true") { //less - false, both - true
                                                                flagBased();
                                                            } else {  //less - false, both - false
                                                                onlyAvailable();
                                                            }
                                                        }
                                                        if(ele.minStkflag == "") {
                                                            if (ele.BothStockFlag == ""){
                                                                flagBased();
                                                                if (ele.stockFlag == "true" || ele.stockFlag == "") {
                                                                    stockDisplay = element.qty;
                                                                } else {
                                                                    stockDisplay = "A";
                                                                }
                                                            } else if(ele.BothStockFlag == "true") {
                                                                stockDisplay = element.qty;
                                                                flagBased();
                                                            } else if(ele.BothStockFlag == "false") {
                                                                stockDisplay = element.qty;
                                                                onlyAvailable();
                                                            }
                                                        } else if(ele.minStkflag == "true") {
                                                            if(ele.BothStockFlag == "") {
                                                                stockDisplay = stockNearAvail(element.qty);
                                                                mrpDisplay = element.mrp;
                                                                spDisplay = element.rmrp;
                                                                offerDisplay = element.offer;
                                                                manufaDisplay = element.manufName;
                                                            }
                                                        } else if(ele.minStkflag == "false") {
                                                            if(ele.BothStockFlag == "") {
                                                                stockDisplay = "A";
                                                                mrpDisplay = element.mrp;
                                                                spDisplay = element.rmrp;
                                                                offerDisplay = element.offer;
                                                                manufaDisplay = element.manufName;
                                                            }
                                                        }
                                                        if(ele.stockFlag == "" && ele.MrpFlag == "" && ele.PriceFlag == "" && ele.OfferFlag == "" && ele.MfgrFlag == "" && ele.minStkflag == "" && ele.BothStockFlag == ""){
                                                            stockDisplay = element.qty;
                                                            mrpDisplay = element.mrp;
                                                            spDisplay = element.rmrp;
                                                            offerDisplay = element.offer;
                                                            manufaDisplay = element.manufName;
                                                        }  
                                                    }
                                                });
                                                var packCheck = "";
                                                if(element.pack == "" || element.pack == null || element.pack == " " ) {
                                                    packCheck = "N/A";
                                                } else {
                                                    packCheck = element.pack.trim();
                                                }
                                                var vendorNameCheck = "";
                                                if(element.distributorName == "" || element.distributorName == null) {
                                                    vendorNameCheck = "N/A";
                                                } else {
                                                    vendorNameCheck = element.distributorName.trim();
                                                }
                                                var batchIdCheck = "";
                                                if(element.batch == "" || element.batch == null) {
                                                    batchIdCheck = "N/A";
                                                } else {
                                                    batchIdCheck = element.batch.trim();
                                                }
                                                availableTagsProductSelection.push({
                                                    label : element.descr.trim(),
                                                    //label : "DOLONEX RAPID 20MG TABDOLONEX RAPID 20MG TAB",
                                                    pack : packCheck,
                                                    value : element.pcode,
                                                    vendorId : element.distributorId,
                                                    schilddistIds : element.sDistId,
                                                    sparentdistIds : element.sParentId,
                                                    parentVendorId : element.parentId,
                                                    vendorName : element.distributorName,
                                                    vendorShortName : vendorNameCheck,
                                                    offer : element.offer,
                                                    offerDisplay:offerDisplay,
                                                    //offer : "10+12",
                                                    avlStock : element.qty,
                                                    stockDisplay : stockDisplay,
                                                    //stockDisplay : 20011,
                                                    mrp : element.mrp,
                                                    mrpDisplay:mrpDisplay,
                                                    //mrp : 100.12222,
                                                    spDisplay:spDisplay,
                                                    sellingPrice : element.rmrp,
                                                    batchId : batchIdCheck,
                                                    mfg_dt : "2016-03-29",
                                                    expDate : "2016-03-29",
                                                    freeStock : 0,
                                                    manufacture : element.manufName,
                                                    manufaDisplay : manufaDisplay.substring(0,5),
                                                    bonus : 0,
                                                    discount : 0
                                                });
                                            });
                                            //console.log("top:  "+JSON.stringify(availableTagsProductSelection.length));
                                            localStorage.setItem("firstResponse_"+ij,JSON.stringify(availableTagsProductSelection));
                                            /*if(localStorage.getItem('First') == 'first') {
                                                localStorage.setItem("firstResponse",JSON.stringify(availableTagsProductSelection));
                                                productAutocmpltLimit = 20;
                                            }*/
                                            if(localStorage.getItem("inputText") == input_) {
                                                localStorage.setItem("inputText","");
                                                productAutocmpltLimit = 10000000;
                                                var session_data_array = "";
                                                for(var i = 0;i < ij;i++) {
                                                    if(localStorage.getItem("firstResponse_"+i)){
                                                        session_data_array = localStorage.getItem("firstResponse_"+i);
                                                        var data = JSON.parse(session_data_array);
                                                    }
                                                    var data = JSON.parse(session_data_array);
                                                    //console.log("for:  "+JSON.stringify(data.length));
                                                    var stockDisplay = 0;
                                                    $.each(data, function(index, element) {
                                                        var thisVenId = element.sparentdistIds;
                                                        var thisStock = element.avlStock;
                                                        var reqSelected = localStorage.getItem("SDList");
                                                                    //console.log(" thisVenId "+thisVenId);
                                                        $.each(JSON.parse(reqSelected), function(index, ele) {
                                                            if(thisVenId == ele.value) {
                                                            //console.log("element.mrp"+thisStock);
                                                                function flagBased() {
                                                                    if (ele.MrpFlag == "true" || ele.MrpFlag == ""){
                                                                        if(element.mrp == "" || element.mrp == null) {
                                                                            mrpDisplay = "N/A";
                                                                        } else {
                                                                            mrpDisplay = element.mrp;
                                                                        }
                                                                    } else { 
                                                                        mrpDisplay = "A";
                                                                    }
                                                                    if (ele.PriceFlag == "true" || ele.PriceFlag == "")
                                                                        spDisplay = element.sellingPrice;
                                                                    else spDisplay = "A";
                                                                    if (ele.OfferFlag == "true" || ele.OfferFlag == "")
                                                                        if(element.offer == "" || element.offer == null) {
                                                                            offerDisplay = "N/A";
                                                                        } else {
                                                                            offerDisplay = element.offer.trim();
                                                                        }
                                                                    else offerDisplay = "A";
                                                                    if (ele.MfgrFlag == "true" || ele.MfgrFlag == "")
                                                                        if(element.manufaDisplay == "" || element.manufaDisplay == null) {
                                                                            manufaDisplay = "N/A";
                                                                        } else {
                                                                            manufaDisplay = element.manufaDisplay.trim();
                                                                        }
                                                                    else manufaDisplay = "A";
                                                                }
                                                                function onlyAvailable(){
                                                                    mrpDisplay = "A";
                                                                    spDisplay = "A";
                                                                    offerDisplay = "A";
                                                                    manufaDisplay = "A";
                                                                }
                                                                if(ele.minStkflag == "true"){
                                                                    stockDisplay = stockNearAvail(element.avlStock);
                                                                    if(ele.BothStockFlag == "true"){ //less - true, both - true
                                                                        flagBased();
                                                                    } else {  //less - true, both - false
                                                                        onlyAvailable();
                                                                    }
                                                                } else {
                                                                    stockDisplay = "A";
                                                                    if(ele.BothStockFlag == "true") { //less - false, both - true
                                                                        flagBased();
                                                                    } else {  //less - false, both - false
                                                                        onlyAvailable();
                                                                    }
                                                                }
                                                                if(ele.minStkflag == "") {
                                                                    if (ele.BothStockFlag == ""){
                                                                        flagBased();
                                                                        if (ele.stockFlag == "true" || ele.stockFlag == "") {
                                                                            stockDisplay = element.avlStock;
                                                                        } else {
                                                                            stockDisplay = "A";
                                                                        }
                                                                    } else if(ele.BothStockFlag == "true") {
                                                                        stockDisplay = element.avlStock;
                                                                        flagBased();
                                                                    } else if(ele.BothStockFlag == "false") {
                                                                        stockDisplay = element.avlStock;
                                                                        onlyAvailable();
                                                                    }
                                                                } else if(ele.minStkflag == "true") {
                                                                    if(ele.BothStockFlag == "") {
                                                                        stockDisplay = stockNearAvail(element.avlStock);
                                                                        mrpDisplay = element.mrp;
                                                                        spDisplay = element.sellingPrice;
                                                                        offerDisplay = element.offer;
                                                                        manufaDisplay = element.manufaDisplay;
                                                                    }
                                                                } else if(ele.minStkflag == "false") {
                                                                    if(ele.BothStockFlag == "") {
                                                                        stockDisplay = "A";
                                                                        mrpDisplay = element.mrp;
                                                                        spDisplay = element.sellingPrice;
                                                                        offerDisplay = element.offer;
                                                                        manufaDisplay = element.manufaDisplay;
                                                                    }
                                                                }
                                                                if(ele.stockFlag == "" && ele.MrpFlag == "" && ele.PriceFlag == "" && ele.OfferFlag == "" && ele.MfgrFlag == "" && ele.minStkflag == "" && ele.BothStockFlag == ""){
                                                                    stockDisplay = element.avlStock;
                                                                    mrpDisplay = element.mrp;
                                                                    spDisplay = element.sellingPrice;
                                                                    offerDisplay = element.offer;
                                                                    manufaDisplay = element.manufaDisplay;
                                                                }  
                                                            }
                                                        });
                                                        var packCheck = "";
                                                        if(element.pack == "" || element.pack == null || element.pack == " ") {
                                                            packCheck = "N/A";
                                                        } else {
                                                            packCheck = element.pack.trim();
                                                        }
                                                        var vendorNameCheck = "";
                                                        if(element.distributorName == "" || element.distributorName == null) {
                                                            vendorNameCheck = "N/A";
                                                        } else {
                                                            vendorNameCheck = element.distributorName.trim();
                                                        }
                                                        var batchIdCheck = "";
                                                        if(element.batchId == "" || element.batchId == null) {
                                                            batchIdCheck = "N/A";
                                                        } else {
                                                            batchIdCheck = element.batchId.trim();
                                                        }
                                                        availableTagsProductSelection.push({
                                                            label : element.label,
                                                            pack : element.pack,
                                                            value : element.value,
                                                            vendorId : element.vendorId,
                                                            schilddistIds : element.schilddistIds,
                                                            sparentdistIds : element.sparentdistIds,
                                                            parentVendorId : element.parentVendorId,
                                                            vendorName : element.vendorName,
                                                            vendorShortName : element.vendorShortName,
                                                            offer : element.offer,
                                                            offerDisplay:offerDisplay,
                                                            avlStock : element.avlStock,
                                                            stockDisplay : stockDisplay,
                                                            mrp : element.mrp,
                                                            mrpDisplay:mrpDisplay,
                                                            spDisplay:spDisplay,
                                                            sellingPrice : element.sellingPrice,
                                                            batchId : element.batchId,
                                                            mfg_dt : element.mfg_dt,
                                                            expDate : element.expDate,
                                                            freeStock : element.freeStock,
                                                            manufaDisplay:manufaDisplay,
                                                            manufacture : element.manufacture,
                                                            bonus : element.bonus,
                                                            discount : element.discount
                                                        });
                                                    });
                                                }
                                            } else {
                                                localStorage.setItem("viewMoreClick",1);
                                                for(var i = 1;i <= ij;i++) {
                                                   localStorage.removeItem("firstResponse_"+i);
                                                }
                                                localStorage.setItem("vMoreIteration",0);
                                            }
                                            response(availableTagsProductSelection.slice(0, productAutocmpltLimit)); 
                                            //console.log("Records  ::  "+JSON.stringify(availableTagsProductSelection.length));
                                            //response(availableTagsProductSelection);
                                            //console.log("top:  "+JSON.stringify(availableTagsProductSelection));
                                        } else {
                                            $("#viewMoreLink1").removeClass("viewMoreShow");
                                            MyError_msg(); $('.errorMsg').text("Sorry, No Records Found");
                                            $('.productAutocompleteTop').mcautocomplete('close');
                                            $('.productIdHidden').val('');
                                            $(".olnyProductAutocompleteTop").hide();
                                            $(".productAutocompleteTop").show();
                                            $(".productAutocompleteTop").focus();
                                            /*$(".olnyProductAutocompleteTop").show();
                                            $(".productAutocompleteTop").hide();
                                            $(".olnyProductAutocompleteTop").val("");
                                            $(".olnyProductAutocompleteTop").focus();*/
                                        } 
                                    },
                                    error: function(xhr, status, error) {
                                        $('.overlay_load').fadeOut();
                                        MyError_msg(); $('.errorMsg').text(serverBusyError);
                                    }
                                });
                            },
                            error: function(xhr, status, error) {
                                $('.overlay_load').fadeOut();
                                MyError_msg(); $('.errorMsg').text(serverBusyError);
                            }
                        });
                    } else {
                        MyError_msg();
                        $('.errorMsg').text("Dear customer, Please select Distributor(s)");
                        $("span",$("#distributorsInput").next()).click();
                    }
                } else {
                    MyError_msg();
                    $('.errorMsg').text("Dear customer, Please select ratiler");
                    $("#retailerInput").focus()
                }
            },
            open: function (event, ui) {
                $("#distributorsInput").parent().removeClass("open");
                /*if(localStorage.getItem("responseLength") == 30) {
                    $('.ui-autocomplete').append('<li style="width:100%;background-color:white;" class="viewMoreLink_"><a class="mcacAnchor c_pointer"><span class="viewMore_autocmplt">View More</span></a></li><li style="width:100%;background-color:white;" class="autocompleteCloseBtn"><a class="mcacAnchor c_pointer"><span class="autocomClose">Close</span></a></li>');
                }*/
                if(localStorage.getItem("responseLength") == 200) {
                    $('.ui-autocomplete').append('<li style="width:100%;background-color:white;" class="viewMoreLink_"><button class="btn btn-sm btn-default" style="width:100%;">Load More Products</button></li>');
                }/* else {
                    $('.ui-autocomplete').append('<li style="width:100%;background-color:white;" class="autocompleteCloseBtn"><a class="mcacAnchor c_pointer"><span class="autocomClose">Close</span></a></li>');
                }*/
                //$(".ui-autocomplete .uiLiBgColor:first").addClass("ui-state-focus");
            },
            focus: function (event, ui) {
                event.preventDefault();
            },
            select: function (event, ui) {
                event.preventDefault();
                $("#viewMoreLink1").removeClass("viewMoreShow");
                if(ui.item.avlStock == 0) {
                    MyError_msg(); $('.errorMsg').text('Sorry, This Product have Zero Available Stock, Please select other Product');
                    $('#productsSearch').val('');
                    $('.prdIdHdn').val('');
                    $('#qtyInputMain').val('');
                    $('#productsSearch').focus();
                } else {
                    $(this).val(ui.item.label);
                    $(this).prev().val(ui.item.value);
                    $(this).attr('pId',ui.item.value);
                    $(this).attr('pVendorId',ui.item.vendorId);
                    $(this).attr('shortchilddistId',ui.item.schilddistIds);
                    $(this).attr('shortparentdistId',ui.item.sparentdistIds);
                    $(this).attr('parentVendorId',ui.item.parentVendorId);
                    $(this).attr('pVendorDesc',ui.item.vendorName);
                    $(this).attr('pVendorShortDesc',ui.item.vendorShortName);
                    $(this).prev().attr('original_hidden',ui.item.value);
                    $(this).attr('pName',ui.item.label);
                    $(this).attr('original_name',ui.item.label+" - "+ui.item.avlStock);
                    $(this).attr('pOffer',ui.item.offer);
                    $(this).attr('offerDisplay',ui.item.offerDisplay);
                    $(this).attr('spDisplay',ui.item.spDisplay);
                    $(this).attr('pStock',ui.item.avlStock);
                    $(this).attr('pMRP',ui.item.mrp);
                    $(this).attr('pSP',ui.item.sellingPrice);
                    $(this).attr('pBatchId',ui.item.batchId);
                    $(this).attr('mfg_dt',ui.item.mfg_dt);
                    $(this).attr('expDate',ui.item.expDate);
                    $(this).attr('freeStock',ui.item.freeStock);
                    $(this).attr('manufacture',ui.item.manufacture);
                    $(this).attr('bonus',ui.item.bonus);
                    $(this).attr('discount',ui.item.discount);
                    $('#qtyInputMain').focus();
                }
            },
            close: function(event, ui) {
            }
        });
        $(document).on('click','.viewMoreLink_',function(){
            var inputText = $("#productsSearch").val();
            $('.overlay_load').fadeIn();
            $("#ajax_loader").show();
            productsSearch = 10000000;
            var availableTagsProductSelection = [];
            $('#productsSearch').val(inputText);
            $('#productsSearch').focus();
            localStorage.setItem("sesondServiceCalling",true);
            localStorage.setItem("viewMoreClick",(parseInt(localStorage.getItem("viewMoreClick"))+200));
            localStorage.setItem("inputText",inputText);
            localStorage.setItem("vMoreIteration",(parseInt(localStorage.getItem("vMoreIteration"))+1));
            $('#productsSearch').mcautocomplete( "search",inputText);
            //console.log(localStorage.getItem("viewMoreClick"));
        });
        $("#DistWiseTot > tbody").hide();
        function AddBtnClick() {
            if($('#prdIdHdn').val()) {
                if($('#qtyInputMain').val() > 0) {
                    var th = $('#productsSearch');
                    if(parseInt($('#qtyInputMain').val()) <= parseInt(th.attr("pStock"))) {
                        var qtyTotal = 0;tableQty = 0;str = '';stockDisplay = '';
                        var updateSameProducts = "";updateSameProductsVend = "";
                        $("#selectedProducts > tbody > tr").each(function(){
                            if($('.pcode_Hidden',this).val() == th.attr('pId') && $('.Schild_vendor',this).val() == th.attr('shortchilddistId') && $('.stock_Hidden',this).val() == th.attr('pStock')) {
                                qtyTotal = +$('.qtySelProdct',this).text() + qtyTotal;
                                tableQty = qtyTotal;
                                updateSameProducts = $('.pcode_Hidden',this).val();
                                updateSameProductsVend = $('.Schild_vendor',this).val();
                            }
                        });
                        qtyTotal = qtyTotal + parseInt($('#qtyInputMain').val());
                        if(parseInt(qtyTotal) <= parseInt(th.attr("pStock"))) {
                            //summary limit start
                            if(localStorage.getItem("userRole") != 9){
                                var str = "";limit="";distr_i="";dist_to="";dis="";
                                Totval = parseFloat($("#qtyInputMain").val()*th.attr('spdisplay')).toFixed(2);
                                var limitsel = localStorage.getItem("SDList");
                                $.each(JSON.parse(limitsel), function(index, elem) {
                                   if(elem.value == th.attr("shortparentdistid")){
                                    limit = elem.limitFlag;
                                   }
                                });
                                if(limit != "0") {
                                    if($("#DistWiseTot > tbody > tr:not('.d_sN')").length) {
                                        $("#DistWiseTot > tbody > tr").each(function(){
                                            if(th.attr("shortparentdistid") == $('.disIdDistWiseT',this).val()){
                                                dist_to = $('.TotDistWiseT',this).text();
                                            }
                                        });
                                        var tota = parseFloat(Totval) + parseFloat(dist_to);
                                         //&& Math.round(limit * 100) > Math.round(tota * 100)
                                        if(Math.round(limit * 100) > Math.round(tota * 100)){
                                            //alert($("#DistWiseTot > tbody > tr > .distrDesc span").text());
                                            
                                        } else{
                                            var distr_i1="";dist_to1="";dis1="";
                                            $("#DistWiseTot > tbody > tr").each(function(){
                                                if(th.attr("shortparentdistid") == $('.disIdDistWiseT',this).val()){
                                                    dis1 = $('.disIdDistWiseT',this).val();
                                                    $("span",$(this)).removeClass("d_sN");
                                                     $(this).attr("title","Your limit is crossed (Rs. "+$(".limitSummHidn",this).val()+")").addClass("c_pointer");
                                                }
                                            });
                                            MyError_msg();
                                            $('.errorMsg').text("Dear customer, Limit crossed for this Distributor");       
                                        }
                                    } else {
                                        if(Math.round(limit * 100) > Math.round(Totval * 100)){
                                            $("span",$("#DistWiseTot > tbody > tr > .distrDesc")).addClass("d_sN");
                                        } else {
                                            var distr_i1="";dist_to1="";dis1="";
                                            $("#DistWiseTot > tbody > tr").each(function(){
                                                if($(this).hasClass("d_sN")){
                                                    if(th.attr("shortparentdistid") == $('.disIdDistWiseT',this).val()){
                                                        dis1 = $('.disIdDistWiseT',this).val();
                                                        $("span",$(this)).removeClass("d_sN");
                                                         $(this).attr("title","Your limit is crossed (Rs. "+$(".limitSummHidn",this).val()+")").addClass("c_pointer");
                                                    }
                                                }
                                            });
                                            MyError_msg();
                                            $('.errorMsg').text("Dear customer, Limit crossed for this Distributor");  
                                        }
                                    }
                                }
                                //summary limit ends
                            }

                            $("#DistWiseTot > tbody").show();
                            if(updateSameProducts == th.attr("pid") && updateSameProductsVend == th.attr("shortchilddistid")) {
                                var newTot = 0;amtAftrChange = 0;
                                $("#selectedProducts > tbody > tr").each(function(){
                                    if(updateSameProducts == $('.pcode_Hidden',this).val() && updateSameProductsVend == $('.Schild_vendor',this).val()) {
                                        $(".qtySelProdct",this).text(parseInt($(".qtySelProdct",this).text()) + parseInt($("#qtyInputMain").val()));
                                        newTot = parseFloat($(".qtySelProdct",this).text()*$(".sp_Hidden",this).val()).toFixed(2);
                                        amtAftrChange = $('.sp_Hidden',this).val() * $("#qtyInputMain").val();
                                        $(".lineTotHiddden",this).val(newTot);
                                        $(".totalsumRW",this).text(newTot);
                                    }
                                });

                                $("#DistWiseTot > tbody > tr").each(function(){
                                    if($(this).hasClass("d_sN")) {
                                        $(this).removeClass("d_sN");
                                    }
                                    if(th.attr("shortparentdistid") == $('.disIdDistWiseT',this).val()) {
                                        var tableLinesSum = parseFloat($('.TotDistWiseT',this).text());
                                        //console.log("tableLinesSum  "+tableLinesSum+"   amtAftrChange   "+amtAftrChange)
                                        $('.TotDistWiseT',this).text(parseFloat(amtAftrChange+tableLinesSum).toFixed(2));
                                    }
                                });
                            } else {
                                $("#DistWiseTot > tbody > tr").each(function(){
                                    if($(this).hasClass("d_sN")) {
                                        $(this).removeClass("d_sN");
                                    }
                                    if(th.attr("shortparentdistid") == $('.disIdDistWiseT',this).val()) {
                                        $('.prodtsDistWiseT',this).text(parseInt($('.prodtsDistWiseT',this).text())+1);
                                        var lineTotal = th.attr('pSP') * $('#qtyInputMain').val();
                                        var tableLinesSum = parseFloat($('.TotDistWiseT',this).text());
                                        $('.TotDistWiseT',this).text(parseFloat(lineTotal+tableLinesSum).toFixed(2));
                                    }
                                });
                                str = "<tr><td class='num'></td><td class='prdDescSele'><input type='hidden' class='stock_Hidden' value='"+th.attr('pStock')+"'><input type='hidden' class='sp_Hidden' value='"+th.attr('pSP')+"'><input type='hidden' class='Schild_vendor' value='"+th.attr('shortchilddistId')+"'><input type='hidden' class='Sparent_vendor' value='"+th.attr('shortparentdistId')+"'><input type='hidden' class='pcode_Hidden' value='"+th.attr('pId')+"'><input type='hidden' class='pVendor_Hidden' value='"+th.attr('parentVendorId')+"'><input type='hidden' class='childID_Hidden' value='"+th.attr('pVendorId')+"'><input type='hidden' class='mrp_hidden' value="+th.attr('pMRP')+"/><input type='hidden' class='manuf_hidden' value="+th.attr('manufacture')+"/><input type='hidden' class='btchID_Hidden' value='"+th.attr('pBatchId')+"'><input type='hidden' class='lineTotHiddden' value="+parseFloat($('#qtyInputMain').val()*th.attr('pSP')).toFixed(2)+">"+th.attr('pName')+"</td><td class='distSel'>"+th.attr('pVendorShortDesc')+"</td><td class='qtySelProdct'>"+$('#qtyInputMain').val()+"</td><td class='txtBold' style='color:#00BFFF'>"+th.attr('spDisplay')+"</td><td class='txtBold' style='color:#2980b9'><span class='totalsumRW'>"+parseFloat($('#qtyInputMain').val()*th.attr('pSP')).toFixed(2)+"</span></td><td><a class='btn btn-danger btn-xs clearROW' style='font-size: 11px;'><i class='fa fa-trash-o'></i></a></td></tr>";
                                //$("#myTable > tbody").append(str);
                                $(str).prependTo($("#selectedProducts > tbody"));
                            }
                            $("#DistWiseTot > tbody > tr").each(function(){
                                if($('.prodtsDistWiseT',this).text() == 0) {
                                    if(!$(this).hasClass("d_sN")) {
                                        $(this).addClass("d_sN");
                                    }
                                }
                            });
                            updateSlnoPrdcts();
                            selPrdGrandTOT();
                            $("#productsSearch").removeAttr("pId").removeAttr("pVendorId").removeAttr("shortchilddistId").removeAttr("shortparentdistId").removeAttr("parentVendorId").removeAttr("pVendorDesc").removeAttr("pVendorShortDesc").removeAttr("pName").removeAttr("pOffer").removeAttr("offerDisplay").removeAttr("spDisplay").removeAttr("pOffer").removeAttr("offerDisplay").removeAttr("spDisplay").removeAttr("pStock").removeAttr("pMRP").removeAttr("pSP").removeAttr("pBatchId").removeAttr("mfg_dt").removeAttr("expDate").removeAttr("freeStock").removeAttr("manufacture").removeAttr("bonus").removeAttr("discount");
                            $('#productsSearch').val('');
                            $('#qtyInputMain').val('');
                            $('.prdIdHdn').val('');
                            $("#productsSearch").val('');
                            $('#productsSearch').focus();
                        } else {
                            var remainQty = parseInt(th.attr("pStock"))-parseInt(tableQty);
                            MyError_msg(); 
                            $('.errorMsg').text('Please enter valid Quantity out of Remaining Quantity ('+remainQty+')');
                            $('#qtyInputMain').val('');
                            $('#qtyInputMain').focus();
                        }   
                    } else {
                        MyError_msg(); $('.errorMsg').text('Quantity should not be greater than Available Stock ('+th.attr("pStock")+')');
                        $('#qtyInputMain').val('');
                        $('#qtyInputMain').focus();
                    }
                } else {
                    MyError_msg();$('.errorMsg').text("Please Enter Quantity");
                    $('#qtyInputMain').val('');
                    $('#qtyInputMain').focus();
                }
            } else {
                MyError_msg();$('.errorMsg').text("Please Select a Product");
               $('#productsSearch').focus();
                
            }
        }
        $("#qtyInputMain").keypress(function (e) {
            if(e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
              MyError_msg(); $('.errorMsg').text('Please enter numeric value');
              return false;
            }
        });
        $(document).on("keyup", "#qtyInputMain", function(event) {
            var va = $(this).val();
            if(va=='0') {
                $(this).val(va.slice(0,-1));
                MyError_msg(); $('.errorMsg').text('Please enter numeric value');
                return false;
            } else {
                return true;
            }
        });
        $(document).on("keydown", "#qtyInputMain", function(event) {
            var keycode = (event.keyCode ? event.keyCode : event.which);
            var th = $(this).parent().parent();
            if(keycode == '13'){
                event.preventDefault();
                AddBtnClick();
            }
        });
        $('#productAddBtn').click(function(){
            AddBtnClick();
        });
        $("#clearALLbtn").click(function(){
            $("#selectedProducts > tbody").html("");
            $("#DistWiseTot > tbody > tr").each(function(){
                $('.prodtsDistWiseT',this).text(0);
                $('.TotDistWiseT',this).text('0.00');
                if(!$(this).hasClass("d_sN")) {
                    $(this).addClass("d_sN");
                }
                if(!$(".distrDesc span",this).hasClass("d_sN")){
                    $(".distrDesc span",this).addClass("d_sN");
                    $(this).removeClass("c_pointer").removeAttr("title");
                }
            });
            $('.distWiseGtotal').text('0.00');
            $('.distWiseTotLines').text('0');
            $("#productsSearch").val('');
            $("#productsSearch").focus();
        });
        $(document).on("click",".clearROW",function(){
            if($("#selectedProducts > tbody > tr").length == 1) {
                $(this).parent().parent().remove();
                $("#DistWiseTot > tbody > tr").each(function(){
                    $('.prodtsDistWiseT',this).text(0);
                    $('.TotDistWiseT',this).text('0.00');
                });
                $('.distWiseGtotal').text('0.00');
                $('.distWiseTotLines').text('0');
                $("#productsSearch").val('');
                $("#productsSearch").focus();
            } else {
                var thisRow = $(this).parent().parent();
                $("#DistWiseTot > tbody > tr").each(function(){
                    if($('.Sparent_vendor',thisRow).val() == $('.disIdDistWiseT',this).val()) {
                        $('.prodtsDistWiseT',this).text(parseInt($('.prodtsDistWiseT',this).text())-1);
                        var lineTotal = parseFloat($('.lineTotHiddden',thisRow).val());
                        var tableLinesSum = parseFloat($('.TotDistWiseT',this).text());
                        $('.TotDistWiseT',this).text(parseFloat(tableLinesSum-lineTotal).toFixed(2));
                        //summary code
                        if(localStorage.getItem("userRole") != 9) {
                            if($(".limitSummHidn",this).val() != "0"){
                                if(Math.round($(".limitSummHidn",this).val()*100) < Math.round($('.TotDistWiseT',this).text()*100)) {
                                    $(".distrDesc span",this).removeClass("d_sN");
                                } else {
                                    $(".distrDesc span",this).addClass("d_sN");
                                    $(this).removeClass("c_pointer").removeAttr("title");
                                }
                            }
                        }
                        //summary code
                    }
                }); 
                thisRow.remove();
                updateSlnoPrdcts();
                selPrdGrandTOT();
            }
            $("#DistWiseTot > tbody > tr").each(function(){
                if($('.prodtsDistWiseT',this).text() == 0) {
                    if(!$(this).hasClass("d_sN")) {
                        $(this).addClass("d_sN");
                    }
                }
            });
        });
        function selVendIDS() {
            var selVenDtls = JSON.parse(localStorage.getItem("SDList"));
            var selVenLst = [];
            $.each(selVenDtls,function(ind,ele){
                selVenLst.push({
                    vendor_id : ele.value
                });
            });
            return selVenLst;
        }
        function logCustName() {
            return $("#retailerInput").val().split(",")[0];
        }
        setInterval(function(){
            var check = 0;check1 = 0;autoSaveToDraftWithVendor = [];rowNo = 1
            if($("#retailerAddHidden").val()){
                $('#selectedProducts > tbody > tr').each(function(){
                    if($('.pcode_Hidden',$(this)).val()) {
                        if($('.lineTotHiddden',$(this)).val()) {
                            check1 = 1;
                            autoSaveToDraftWithVendor.push({
                                product : $(".pcode_Hidden",this).val(),
                                qty : $(".qtySelProdct",this).text(),
                                BatchidList : $(".btchID_Hidden",this).val(),
                                childVendorList : $(".Schild_vendor",this).val(),
                                vendorId : $(".Sparent_vendor",this).val(),
                                reqLineSum : $(".lineTotHiddden",this).val(),
                                reqLine : rowNo
                            });
                        }
                    }
                    rowNo++;
                });
            }
            if(check1 == 1) {
                var param = {requisition_data:autoSaveToDraftWithVendor};
                if(localStorage.getItem("paramForSaveAsDraftCheck")) {
                    if(JSON.stringify(param) === localStorage.getItem("paramForSaveAsDraftCheck")) {
                        check = 0;
                    } else {
                        check = 1;
                    }
                } else if(autoSaveToDraftWithVendor.length > 0) {
                    check = 1;
                }
                var Nparam = {requisition_data:autoSaveToDraftWithVendor};
                localStorage.setItem("paramForSaveAsDraftCheck",JSON.stringify(Nparam));
            }
            if(check == 1) {
                //calling save as draft service
                $.ajax({
                    data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:$('#retailerAddHidden').val(),draftId:$("#draftIDpgLvl").val(),reqDate:todayDate,requisition_data:autoSaveToDraftWithVendor},
                    url : 'http://'+ip+'/ThillaisServices/rest/ReqDraft/WantdDraftInsertion',
                    type : 'POST',
                    dataType: 'json',
                    success: function(data) {
                        $('#draftIDpgLvl').val(data.d);
                        /*if(data.result == 'SUCCESS') {     
                            MySuccess_msg(); $('.successMsg').text('Successfully Saved');
                            
                        } else {
                            MyError_msg(); $('.errorMsg').text('Unable to Save, Please try again');
                        }*/
                    },
                    error: function(xhr, status, error) {
                        MyError_msg();$('.errorMsg').text(serverBusyError);
                    }
                });
            }
        }, 10000);
        //save as draft
        $(document).on("click","#saveDraft",function(e){
            if($("#retailerAddHidden").val()) {
                var requisition_data = [];row = 1;check = 0;
                $("#selectedProducts > tbody > tr").each(function(){
                    if($(".pcode_Hidden").val()){
                        check++;
                        requisition_data.push({
                            product : $(".pcode_Hidden",this).val(),
                            qty : $(".qtySelProdct",this).text(),
                            BatchidList : $(".btchID_Hidden",this).val(),
                            childVendorList : $(".Schild_vendor",this).val(),
                            vendorId : $(".Sparent_vendor",this).val(),
                            reqLineSum : $(".lineTotHiddden",this).val(),
                            reqLine : row
                        });
                        row++;
                    }
                });
                if(check != 0){
                    $('.overlay_load').fadeIn();
                    var param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:$('#retailerAddHidden').val(),draftId:$("#draftIDpgLvl").val(),reqDate:todayDate,requisition_data:requisition_data};
                    $.ajax({
                        data: param,
                        url : 'http://'+ip+'/ThillaisServices/rest/ReqDraft/WantdDraftInsertion',
                        type : 'POST',
                        dataType: 'json',
                        global: true,
                        success: function(data) {
                            if(data) {
                                if(data.r == "SUCCESS") {
                                    $('#draftIDpgLvl').val(data.d);
                                    MySuccess_msg(); $('.successMsg').text('Successfully Saved');
                                } else {
                                    MyError_msg(); $('.errorMsg').text('Unable to Save, Please try again');
                                }
                            } else {
                                MyError_msg();$('.errorMsg').text("Failed to save product details");
                            }
                            $('.overlay_load').fadeOut();
                        },
                        error: function(xhr, status, error) {
                            MyError_msg();$('.errorMsg').text(serverBusyError);
                            $('.overlay_load').fadeOut();
                        }
                    });
                } else {
                    MyError_msg(); $('.errorMsg').text('Please select atleast one product to save');
                    $("#productsSearch").focus();
                }
            } else {
                MyError_msg(); $('.errorMsg').text('Please select Retailer name');
                $("#retailerInput").val('').focus();
            }
        });
        $(document).on("click","#openDraft",function(e){
            if($("#retailerAddHidden").val()) {
                $("#clearALLbtn").click();
                $('.overlay_load').fadeIn();
                $('#draftOpnTable').DataTable().destroy();
                var param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:$('#retailerAddHidden').val(),userRole:localStorage.getItem("userRole")};
                $.ajax({
                    data: param,
                    url : 'http://'+ip+'/ThillaisServices/rest/ReqDraft/WantdraftDetailNew',
                    type : 'POST',
                    dataType: 'json',
                    global: true,
                    success: function(data) {
                        var str = '';sno = 1;
                        $.each(data, function(index, element) {
                            str = str + '<tr><td class="SNnum drftRwClk c_pointer">'+sno+'</td><td class="drftRwClk c_pointer"><input type="hidden" class="cstIDhidn" value="'+element.a+'"><input type="hidden" class="drftIdHidn" value="'+element.e+'"><input type="hidden" class="drftStatus_hidden" value="'+element.g+'"><input type="hidden" class="drftDate_hidden" value="'+element.f+'">'+$("#retailerInput").val()+'</td><td class="drftRwClk c_pointer">'+element.i+'</td><td class="drftRwClk c_pointer">'+element.f+'</td><td class="text-center"><span class="del_drft_rw c_pointer"><i class="fa fa-trash-o iconF-18"></i></span></td></tr>';
                            sno++;
                        });
                        $('#draftOpnTable > tbody').html(str);
                        $('#draftOpnTable').DataTable({
                            responsive: true
                        });
                        $(".custNamePOP").text(logCustName());
                        $('#draftSearchDetails').modal("show");
                        $('.overlay_load').fadeOut();
                    },
                    error: function(xhr, status, error) {
                        MyError_msg();$('.errorMsg').text(serverBusyError);
                        $('.overlay_load').fadeOut();
                    }
                });
            } else {
                MyError_msg(); $('.errorMsg').text('Please select Retailer name');
                $("#retailerInput").val('').focus();
            }
        });
        $(document).on("click",".drftRwClk",function(){
            $('#draftSearchDetails').modal("hide");
            $('.overlay_load').fadeIn();
            $("#DistWiseTot > tbody > tr").each(function(){
                $('.prodtsDistWiseT',this).text(0);
                $('.TotDistWiseT',this).text('0.00');
            }); 
            //$("#clearALLbtn").click();
            var ts = $(this).parent();
            $.ajax({
                data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:$(".cstIDhidn",ts).val(),draftId:$(".drftIdHidn",ts).val(),draftStatus:$(".drftStatus_hidden",ts).val()},
                url : 'http://'+ip+'/ThillaisServices/rest/ReqDraft/WantDraftCopyNew',
                type : 'POST',
                dataType: 'json',
                global: true,
                success: function(data) {
                    //localStorage.setItem("draftdist",data.n);
                    if(data) {
                        $("#draftIDpgLvl").val(data.a);
                        var str = '';ij = 0;disableLIs = "";
                        while(ij < data.d.length) { //productid
                            $('.optWrapper ul li',$("#distributorsInput").parent()).each(function(){
                                var dist_ = $(this).attr('data-val');
                                if(dist_ == data.n[ij]){
                                    if($(this).hasClass("selected")){

                                    } else {
                                        if($(this).hasClass("disabled")) {
                                            disableLIs += $(this).attr("data-val")+",";
                                        } else {
                                            $(this).trigger('click');
                                        }
                                    }
                                }
                            });
                            var thisVenId = data.n[ij];spDisplay = "";
                            var reqSelected = localStorage.getItem("SDList");
                            //console.log(" ele "+element.manufName);
                            $.each(JSON.parse(reqSelected), function(index, ele) {
                                if(thisVenId == ele.value) {
                                //console.log("product"+thisVenId+" ele "+ele.vendor_id);
                                    function flagBased() {
                                        if (ele.PriceFlag == "true" || ele.PriceFlag == "")
                                            spDisplay = data.h[ij];
                                        else spDisplay = "A";
                                    }
                                    function onlyAvailable(){
                                        spDisplay = "A";
                                    }
                                    if(ele.minStkflag == "true"){
                                        if(ele.BothStockFlag == "true"){ //less - true, both - true
                                            flagBased();
                                        } else {  //less - true, both - false
                                            onlyAvailable();
                                        }
                                    } else {
                                        if(ele.BothStockFlag == "true") { //less - false, both - true
                                            flagBased();
                                        } else {  //less - false, both - false
                                            onlyAvailable();
                                        }
                                    }
                                    if(ele.minStkflag == "") {
                                        if (ele.BothStockFlag == ""){
                                            flagBased();
                                        } else if(ele.BothStockFlag == "true") {
                                            flagBased();
                                        } else if(ele.BothStockFlag == "false") {
                                            onlyAvailable();
                                        }
                                    } else if(ele.minStkflag == "true") {
                                        if(ele.BothStockFlag == "") {
                                            spDisplay = data.h[ij];
                                        }
                                    } else if(ele.minStkflag == "false") {
                                        if(ele.BothStockFlag == "") {
                                            spDisplay = data.h[ij];
                                        }
                                    }
                                    if(ele.stockFlag == "" && ele.MrpFlag == "" && ele.PriceFlag == "" && ele.OfferFlag == "" && ele.MfgrFlag == "" && ele.minStkflag == "" && ele.BothStockFlag == ""){
                                        spDisplay = data.h[ij];
                                    }  
                                }
                            });
                            str += '<tr><td class="num"></td><td class="prdDescSele"><input type="hidden" value="'+data.e[ij]+'" class="ProDescrHidn"><input type="hidden" value="'+data.c[ij]+'" class="VenDescrHden"><input type="hidden" value="'+data.f[ij]+'" class="offerHidden"><input type="hidden" value="'+data.d[ij]+'" class="pcode_Hidden"><input type="hidden" value="'+data.n[ij]+'" class="pVendor_Hidden"><input type="hidden" value="'+data.n[ij]+'" class="Sparent_vendor"><input type="hidden" value="'+data.b[ij]+'" class="childID_Hidden"><input type="hidden" value="'+data.b[ij]+'" class="Schild_vendor"><input type="hidden" value="'+data.m[ij]+'" class="btchID_Hidden"><input type="hidden" value="'+data.j[ij]+'" class="stock_Hidden"><input type="hidden" value="'+data.g[ij]+'" class="mrpHidden"><input type="hidden" class="sp_Hidden" value="'+data.h[ij]+'"><input type="hidden" class="lineTotHiddden" value="'+parseFloat(data.i[ij] * data.h[ij]).toFixed(2)+'">'+data.e[ij]+'</td><td class="distSel">'+data.c[ij]+'</td><td class="qtySelProdct">'+data.i[ij]+'</td><td class="txtBold" style="color:#00BFFF">'+spDisplay+'</td><td class="txtBold" style="color:#2980b9"><span class="totalsumRW">'+parseFloat(data.i[ij] * data.h[ij]).toFixed(2)+'</span></td><td><a class="btn btn-danger btn-xs clearROW" style="font-size: 11px;"><i class="fa fa-trash-o"></i></a></td></tr>';
                            ij++;
                        }
                        $("#selectedProducts > tbody").html(str);
                        $("#DistWiseTot > tbody").show();
                        $("#selectedProducts > tbody > tr").each(function(){
                            var th = $(this);
                            var lineTot = parseFloat($(".lineTotHiddden",this).val());
                            $("#DistWiseTot > tbody > tr").each(function(){
                                if($(this).hasClass("d_sN")) {
                                    $(this).removeClass("d_sN");
                                }
                                if($('.pVendor_Hidden',th).val() == $('.disIdDistWiseT',this).val()) {
                                    //alert("before  "+$('.prodtsDistWiseT',this).text())
                                    $('.prodtsDistWiseT',this).text(parseInt($('.prodtsDistWiseT',this).text())+1);
                                    var tableLinesSum = parseFloat($('.TotDistWiseT',this).text());
                                    $('.TotDistWiseT',this).text(parseFloat(lineTot+tableLinesSum).toFixed(2));
                                }
                            }); 
                        });
                        var disableLiSplit = disableLIs.slice(0,-1).split(",");
                        $("#selectedProducts > tbody > tr").each(function(){
                            var th = $(this);
                            var pVen = $(".pVendor_Hidden",th).val();
                            for(var a = 0;a < disableLiSplit.length;a++){
                                if(disableLiSplit[a] == pVen){
                                    $(".clearROW",th).click();
                                }
                            }
                        });
                        $("#DistWiseTot > tbody > tr").each(function(){
                            if($('.prodtsDistWiseT',this).text() == 0) {
                                $(this).addClass("d_sN");
                            }
                        });
                        //summary limit code starts
                        if(localStorage.getItem("userRole") != 9) {
                            var ij = 0;
                            while(ij < data.d.length) { //productid
                                var thisVenId = data.n[ij];
                                var limit="";distr_i="";dist_to="";dis="";
                                //var Totval = parseFloat(data.i[ij]*data.h[ij]).toFixed(2);
                                var summTot = 0;
                                $("#DistWiseTot > tbody > tr").each(function(){
                                    /*if(!$(".distrDesc span",this).hasClass("d_sN")) {
                                        $(".distrDesc span",this).addClass("d_sN");
                                        $(this).removeClass("c_pointer").removeAttr("title");
                                    }*/
                                    if(!$(this).hasClass("d_sN")) {
                                        if(thisVenId == $('.disIdDistWiseT',this).val()){
                                            summTot += $('.TotDistWiseT',this).text();
                                        }
                                    }
                                });
                                var limitsel = localStorage.getItem("SDList");
                                $.each(JSON.parse(limitsel), function(index, elem) {
                                   if(elem.value == thisVenId){
                                    limit = elem.limitFlag;
                                   }
                                });
                                if(limit != 0) {
                                    if($("#DistWiseTot > tbody > tr:not('.d_sN')").length) {
                                        if(Math.round(limit * 100) > Math.round(summTot * 100)){
                                            //$("span",$("#DistWiseTot > tbody > tr > .distrDesc")).addClass("d_sN");
                                        } else {
                                            $("#DistWiseTot > tbody > tr").each(function(){
                                                if(!$(this).hasClass("d_sN")) {
                                                    if(thisVenId == $('.disIdDistWiseT',this).val()){
                                                        $(".distrDesc span",this).removeClass("d_sN");
                                                        $(this).attr("title","Your limit is crossed (Rs. "+$(".limitSummHidn",this).val()+")").addClass("c_pointer");
                                                    }
                                                }
                                            });
                                        }
                                    }
                                }
                                ij++;
                            }
                        }
                        //summary limit code ends
                        $('#productsDistrDetails').modal("hide");
                        //$("#productsDivsHide").show();
                        updateSlnoPrdcts();
                        selPrdGrandTOT();
                    } else {
                        MyError_msg();$('.errorMsg').text("Sorry, Failed to get data");
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                    $('.overlay_load').fadeOut();
                }
            });
        });
        $(document).on("click",".del_drft_rw",function(){
            var ts = $(this).parent().parent();
            $('#delete_custId').val($('.cstIDhidn',ts).val());
            $('#delete_draftId').val($('.drftIdHidn',ts).val());
            $("#delete_draftStatus").val($('.drftStatus_hidden',ts).val())
            $(this).parent().parent().addClass("selected");
            $('#draft_delete_trigger').click();
        });
        $(document).on("click","#delete_draft_yes",function(){
            /*var vendorId = [];
            $("#selectedProducts > tbody > tr").each(function(){
                vendorId.push({
                    vendor_id : $(".pVendor_Hidden",this).val()
                });
            });*/
            $.ajax({
                data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:$("#delete_custId").val(),draftId:$("#delete_draftId").val()},
                url : 'http://'+ip+'/ThillaisServices/rest/ReqDraft/WantDraftdeleteNew',
                type : 'POST',
                dataType: 'json',
                global: true,
                success: function(data) {
                    if(data.r == "Success") {
                        var i = 0;j = 0;
                        var rows = $("#draftOpnTable").dataTable().fnGetNodes();
                        while(j < rows.length) {
                            if($(rows[j]).hasClass("selected")) {
                                $('#draftOpnTable').DataTable().row($(rows[j])).remove().draw( false );
                                i--;
                            }
                            $(".SNnum",rows[j]).text(i+1);
                            i++;
                            j++;
                        }
                        $('#delete_draft_no').click();
                        MySuccess_msg(); $('.successMsg').text('Successfully Deleted');
                    } else {
                        $('#delete_draft_no').click();
                        var j = 0;
                        var rows = $("#draftOpnTable").dataTable().fnGetNodes();
                        while(j < rows.length) {
                            if($(rows[j]).hasClass("selected")) {
                                $(rows[j]).removeClass("selected");
                            }
                        }
                        MyError_msg(); $('.errorMsg').text('Unable to Delete, Please try again');
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                    $('.overlay_load').fadeOut();
                }
            });
        });
        $("#PriorityTab").click(function(){
            if(!$(this).hasClass("active")) {
                if(localStorage.getItem("userRole") != 9) {
                    $('.overlay_load').fadeIn();
                    $("#clearALLbtn").click();
                    $.ajax({
                        data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd")},
                        url : 'http://'+ip+'/ThillaisServices/rest/req/getWebUserEntity',
                        type : 'POST',
                        dataType: 'json',
                        success: function(data) {
                            if(data && data.length != 0){
                                var retailerPriorTags = [];
                                $.each(data, function(index, element) {
                                    if(element.a) {
                                        retailerPriorTags.push({
                                            label: element.b.trim()+", "+element.c.trim(),
                                            value: element.a
                                        });
                                    }
                                });
                                $("#retailerPriorDesc").autocomplete({
                                    source: retailerPriorTags,
                                    focus : function(event,ui) {
                                        event.preventDefault();
                                    },
                                    select : function(event,ui) {
                                        event.preventDefault();
                                        $(".shwpriormodel").slideUp();
                                        $("#retailerPriorDesc").val(ui.item.label);
                                        $('#retailerPriorDesc').attr('original_name',ui.item.label);
                                        $('#retailerHiddenId').val(ui.item.value);
                                        $('#retailerHiddenId').attr('original_hidden',ui.item.value);
                                        //distrPriority();
                                    }
                                }).bind('focus', function(){ $(this).autocomplete("search"," "); } );
                                
                                if(retailerPriorTags.length == 1) {
                                    $('#retailerHiddenId').val(retailerPriorTags[0].value);
                                    $('#retailerHiddenId').attr('original_hidden',retailerPriorTags[0].value);
                                    $("#retailerPriorDesc").val(retailerPriorTags[0].label);
                                    $('#retailerPriorDesc').attr('original_name',retailerPriorTags[0].label);
                                    distrPriority();
                                } else {
                                    $("#retailerPriorDesc").focus();
                                    $('.overlay_load').fadeOut();
                                }
                            } else {
                                $('.overlay_load').fadeOut();
                                MyError_msg(); $('.errorMsg').text("Dear customer, Faild to get retailer details, please try later ");
                            }
                        },
                        error: function(xhr, status, error) {
                            MyError_msg();$('.errorMsg').text(serverBusyError);
                        }
                    });
                }
            }
        });
        $(document).on("click",".searchBtnPrior",function(){
            if($("#retailerHiddenId").val()) {
                distrPriority();
            } else {
                MyError_msg(); $('.errorMsg').text('Please Select Reatiler Name');
                $("#retailerPriorDesc").focus();
            }
        });
        $(document).on("keyup","#retailerPriorDesc",function(){
            if($(this).attr("autocomplete")) {
                event.preventDefault();
                if($(this).attr('original_name') != $(this).val()) {
                    $(this).prev().val('');
                    $(this).prev().attr('original_hidden','');
                    $(this).attr('original_name','');
                    $(".shwpriormodel").slideUp();
                }
            }
        });
        function distrPriority (){
            $('#Distr_prior').dataTable().fnDestroy();
            $(".shwpriormodel").hide();
            $('.overlay_load').fadeIn();
            $.ajax({
                data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),c_id_abbr : $("#retailerHiddenId").val()},
                url : 'http://'+ip+'/ThillaisServices/rest/req/gettingMappedVendorPrefDetails',
                type : 'POST',
                dataType: 'json',
                global: true,
                success: function(data) {
                    if(data) {
                        var str = "";sno = 1;
                        $.each(data, function(index, element) {
                            var limitVAL = "";
                            if(element.c == "0") {
                                limitVAL = "";
                            } else {
                                limitVAL = element.c;
                            }
                            str += '<tr><td><span class="srNo"><span>'+sno+'</td><td><input type="hidden" class="Vendor_id" value="'+element.a+'"><input type="hidden" class="VendorDescr" value="'+element.b+'">'+element.b+'</td><td><input type="text" value="'+limitVAL+'" class="form-control limitInputPriorit" placeholder="Limit" style="width:100% !important;"></td><td><a class="btn btn-success btn-xs setpriority" style="font-size: 11px;"><i class="fa fa-chevron-right" aria-hidden="true"></i></a></td></tr>';
                            sno ++;
                        });
                        $("#Distr_prior > tbody").html(str);
                        $("#Distr_prior").DataTable({
                            columnDefs: [
                                { width: '10%', targets: 0 },
                                { width: '55%', targets:  1},
                                { width: '25%', targets:  2},
                                { width: '10%', targets:  3}
                            ],
                            "autoWidth":false,
                            "initComplete": function(settings, json) {
                                $(".shwpriormodel").slideDown();
                            },
                            "paging":   false,
                            "ordering": false,
                            "info":     false
                        });
                        $("#Distr_prior_wrapper div:first div:first").html("<h4>Distributors</h4>");
                        $("#Distr_prior_filter").parent().removeClass("col-sm-6").addClass("col-sm-3")
                        $("#Distr_prior_filter").parent().parent().append('<div class="col-sm-3"><button type="button" id="updateLimitBtn" class="btn btn-sm btn-default text-right" style="font-weight: bold !important;float: right;margin-top: 4px;">Update Limit</button></div>');
                    } else {
                        MyError_msg();$('.errorMsg').text("Dear customer, Unable to  search Distributor, please try later");
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                    $('.overlay_load').fadeOut();
                }
            });
        }
        function dataTableUpdate(tableID,addingRow) {
            var i = 0;j = 0;
            var rows = $("#"+tableID).dataTable().fnGetNodes();
            while(j < rows.length) {
                if(addingRow == "deleting") {
                    if($(rows[j]).hasClass("selctd")) {
                        $("#"+tableID).DataTable().row($(rows[j])).remove().draw( false );
                        i--;
                    }
                }
                $(".srNo",rows[j]).text(i+1);
                i++;
                j++;
            }
        }
        $('#Distr_prior1').DataTable({
            "paging":   false,     
            "ordering": false,
            "info": false,
            /* "searching": false, */
            columnDefs: [
                { width: '10%', targets: 0 },
                { width: '55%', targets:  1},
                { width: '25%', targets:  2},
                { width: '10%', targets:  3}
            ],
            "autoWidth":false,
        });
        $("#Distr_prior1_wrapper div:first div:first").html("<h4>Priority Distributors</h4>");
        $("#Distr_prior1_wrapper div:first div:nth-child(2)").html('<button type="button" id="updatePriorBtn" class="btn btn-sm btn-default text-right" style="font-weight: bold !important;float: right;margin-top: 4px;">Update Priority</button>');

        $('body').on('click','.setpriority',function(){
            var th = $(this).parent().parent();
            if($('#Distr_prior1 > tbody > tr:first-child > td').hasClass("dataTables_empty")) {
                $('#Distr_prior1 > tbody > tr:first-child').remove();
            }
            $('#Distr_prior1').DataTable().row.add([
                '<span class="srNo"><span>'+($("#Distr_prior1 > tbody > tr").length+1),
                '<input type="hidden" class="prefVendor_id" value="'+$('.Vendor_id',th).val()+'"><input type="hidden" class="prefVendorDescr" value="'+$('.VendorDescr',th).val()+'">'+$('.VendorDescr',th).val(),
                '<td><input type="text" value="'+$('.limitInputPriorit',th).val()+'" class="form-control limitInputPriorit1" placeholder="Limit" style="width:100% !important;"></td>',
                '<a class="btn btn-success btn-xs setpriorback" style="font-size: 11px;"><i class="fa fa-chevron-left" aria-hidden="true"></i></a>'
            ]).draw( false );
            th.addClass("selctd");
            dataTableUpdate("Distr_prior","deleting");
            dataTableUpdate("Distr_prior1","adding");
        });

        $('body').on('click','.setpriorback',function(){
            var th = $(this).parent().parent();
            $('#Distr_prior').DataTable().row.add([
                '<span class="srNo"><span>'+($("#Distr_prior > tbody > tr").length+1),
                '<input type="hidden" class="Vendor_id" value="'+$('.prefVendor_id',th).val()+'"><input type="hidden" class="VendorDescr" value="'+$('.prefVendorDescr',th).val()+'">'+$('.prefVendorDescr',th).val(),
                '<td><input type="text" value="'+$('.limitInputPriorit1',th).val()+'" class="form-control limitInputPriorit" placeholder="Limit" style="width:100% !important;"></td>',
                '<a class="btn btn-success btn-xs setpriority" style="font-size: 11px;"><i class="fa fa-chevron-right" aria-hidden="true"></i></a>'
            ]).draw( false );
            th.addClass("selctd");
            dataTableUpdate("Distr_prior1","deleting");
            dataTableUpdate("Distr_prior","adding");

        });
        $(document).on("keypress",".limitInputPriorit, .limitInputPriorit1",function(e){
            if (e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
              MyError_msg(); $('.errorMsg').text('Please enter numeric value');
              return false;
            }
        });
        $(document).on("keyup",".limitInputPriorit, .limitInputPriorit1",function(){
            var va = $(this).val();
            if(va=='0') {
                $(this).val(va.slice(0,-1));
                MyError_msg(); $('.errorMsg').text('Please enter numeric value');
                return false;
            } else {
                return true;
            }
        });
        function LimitPriorServce() {
            var vendata = [];rowNo = 1;
            if(!$('#Distr_prior1 > tbody > tr:first-child > td').hasClass("dataTables_empty")) {
                var i = 0;j = 0;
                var rows = $("#Distr_prior1").dataTable().fnGetNodes();
                while(j < rows.length) {
                    var limitVal = "";
                    if($(".limitInputPriorit1",rows[j]).val() == "") {
                        limitVal = 0;
                    } else {
                        limitVal = $(".limitInputPriorit1",rows[j]).val();
                    }
                    vendata.push({
                        vendorid : $(".prefVendor_id",rows[j]).val(),
                        limit : limitVal,
                        preference : rowNo  //$(".srNo",this).text()
                    });
                    rowNo++;
                    j++;
                }
            }
            var rows = $("#Distr_prior").dataTable().fnGetNodes();j = 0;
            while(j < rows.length) {
                var limitVal = "";
                if($(".limitInputPriorit",rows[j]).val() == "") {
                    limitVal = 0;
                } else {
                    limitVal = $(".limitInputPriorit",rows[j]).val();
                }
                vendata.push({
                    vendorid : $(".Vendor_id",rows[j]).val(),
                    limit : limitVal,
                    preference : rowNo  //$(".srNo",this).text()
                });
                rowNo++;
                j++;
            }
            var param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),c_id_abbr: $("#retailerHiddenId").val(),requisition_data:vendata};
            $.ajax({
                data: param,
                url : 'http://'+ip+'/ThillaisServices/rest/req/updateMappedDistributorPref',
                type : 'POST',
                async : 'false',
                dataType: 'json',
                success: function(data) {
                    if(data.Success) {
                        localStorage.setItem("flashMsg","Successfully Saved Distributor Priority/Limit Details");
                        location.reload();
                    } else {
                        MyError_msg();$('.errorMsg').text("Unable to save, Please try after sometime");
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);$('.overlay_load').fadeOut();
                }
            });
        }
        $(document).on("click","#updatePriorBtn, #updateLimitBtn",function(){
            if($(this).attr("id") == "updatePriorBtn") {
                if(!$('#Distr_prior1 > tbody > tr:first-child > td').hasClass("dataTables_empty")) {
                    $('.overlay_load').fadeIn();
                    LimitPriorServce();
                } else {
                    MyError_msg();$('.errorMsg').text("Please move atleast one distributor to update priority details");
                }
            } else if($(this).attr("id") == "updateLimitBtn") {
                if(!$('#Distr_prior > tbody > tr:first-child > td').hasClass("dataTables_empty")) {
                    $('.overlay_load').fadeIn();
                    LimitPriorServce();
                } else {
                    MyError_msg();$('.errorMsg').text("No distributor details found to update limit");
                }
            }
            
        });
        $("#orSearchTab").click(function(){
            if($(this).hasClass("active")) {

            } else {
                if(localStorage.getItem("userRole") != 9) {
                    $("#clearALLbtn").click();
                    $("#searchBtn").click();
                    $('.flash-message').remove();
                }
            }
        });
        $(document).on("keyup", '#retailerSearch, #distributorSearch', function(event) {
            if($(this).attr("autocomplete")) {
                event.preventDefault();
                if($(this).attr('original_name') != $(this).val()) {
                    $(this).prev().val('');
                    $(this).prev().attr('original_hidden','');
                    $(this).attr('original_name','');
                    $(".soIdSearchDIV").slideUp();
                }
            }
        });
        $("#searchBtn").click(function() {
            $('#soidSearchTable').dataTable().fnDestroy();
            if($("#retailerSearchHidden").val()){
                var fullDateSplit = $("#fromToDate").val().split(" To ");
                $('.overlay_load').fadeIn();
                $(".soIdSearchDIV").hide();
                $.ajax({
                    data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),custId:$("#retailerSearchHidden").val(),entityid:$("#disrbtrSearchHidden").val(),fromDate:fullDateSplit[0],toDate:fullDateSplit[1],userRole:localStorage.getItem("userRole")},
                    url : 'http://'+ip+'/ThillaisServices/rest/so/w_salesOrderExistingDetails',
                    type : 'POST',
                    dataType: 'json',
                    global: true,
                    success: function(data) {
                        if(data) {
                            var str = "";
                            $.each(data, function(index, element) {
                                str += '<tr call="t"><td>'+(index+1)+'</td><td class="searchRowPlus"><i class="fa fa-plus-circle expandCls" style="font-size:15px !important;"></i></td><td><input type="hidden" class="rowIndexHidd"><input type="hidden" class="distIdSearchRow" value="'+element.a+'"><input type="hidden" class="distBillSearchRow" value="'+element.h+'"><input type="hidden" class="distNameSearchRow" value="'+element.b+'"><input type="hidden" class="orderNoSearchRow" value="'+element.d+'"><input type="hidden" class="orderDateSearchRow" value="'+element.f+'">'+element.b+'</td><td class="text-center">'+element.f+'</td><td class="text-center">'+element.d+'</td><td class="text-center">'+element.h+'</td><td class="text-center">'+element.p+'</td><td class="text-center">';
                                if(element.c == '3') {
                                    str += '<i class="fa fa-check btn btn-info btn-xs"></i>';
                                } else {
                                    str += '<i class="fa fa-exclamation-circle btn btn-xs" style="font-size:120%;" title="Order Still Pending"></i>';
                                }
                                str += '</td><td class="text-center"> <div class="btn btn-success btn-xs rowOrderView" title="View Soid Details"><i class="fa fa-edit"></i> View </div><div class=btn-group CSVDown><button aria-expanded=false aria-haspopup=true class="btn btn-info btn-xs btn_white dropdown-toggle" data-toggle=dropdown type=button><li class="fa fa-download"></li> Download <span class="caret"></span></button><ul class="dropdown-menu dow"><li><span class="btn btn-xs rowCSVDwnld" title="CSV Download"><i class="fa fa-download"></i> CSV Format 1</span><li><span class="btn btn-xs rowCSVDwnld2" title="CSV Download" style="margin-top: 5px;"><i class="fa fa-download"></i> CSV Format 2</span></ul></div></td></tr>';
                            });
                            $("#soidSearchTable > tbody").html(str);
                            $('#soidSearchTable tr td:not(:last-child)').addClass("searchRowClk c_pointer");
                            $('#soidSearchTable tr td:nth-child(2)').removeClass("searchRowClk");
                            $("#soidSearchTable").DataTable({
                                columnDefs: [
                                    { width: '4%', targets: 0 },
                                    { width: '3%', targets:  1},
                                    { width: '30%', targets: 2 },
                                    { width: '10%', targets: 3 },
                                    { width: '10%', targets: 4 },
                                    { width: '8%', targets: 5},
                                    { width: '7%', targets: 6 },
                                    { width: '7%', targets: 7 },
                                    { width: '15%', targets: 8 }
                                ],
                                "autoWidth":false
                            });
                            $(".soIdSearchDIV").slideDown();
                        } else {
                            MyError_msg();$('.errorMsg').text("Dear customer, Unable to get search records, please try later");
                        }
                        $('.overlay_load').fadeOut();
                    },
                    error: function(xhr, status, error) {
                        MyError_msg();$('.errorMsg').text(serverBusyError);
                        $('.overlay_load').fadeOut();
                    }
                });
            } else {
                MyError_msg();$('.errorMsg').text("Please select Retailer");
                $("#retailerSearch").focus();
            }
        });
        function dataTablePagenateIndex() {
            var i = 0;
            $("#soidSearchTable > tbody > tr").each(function(){
                if(!$(this).hasClass("subTableRow")) {
                    $(".rowIndexHidd",this).val(i);
                    i++;
                }
            });
        }
        $(document).on("click",".searchRowPlus",function(){
            dataTablePagenateIndex();
            var th = $(this).parent();
            var $this = $(this);
            if(th.attr("call") == "t") {
                var rowIndex = $(".rowIndexHidd",th).val();
                //var rowIndex = $("#soidSearchTable").DataTable().row( th ).id();
                var param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:$("#retailerSearchHidden").val(),entityId:$(".distIdSearchRow",th).val(),soid:$(".orderNoSearchRow",th).val(),userRole:localStorage.getItem("userRole")}
                $('.overlay_load').fadeIn();
                $.ajax({
                    data: param,
                    url : 'http://'+ip+'/ThillaisServices/rest/so/WantedNotesalesOrderInformation',
                    type : 'POST',
                    dataType: 'json',
                    global: true,
                    success: function(data) {
                        if(data) {
                            /*th.attr("call","f");
                            $(".expandCls",th).removeClass("fa-plus-circle").addClass("fa-minus-circle");
                            var i = 0;str = "<tr class='mySub'><th>Sno</th><th>Product</th><th>Order Qty</th><th>Supply Qty</th></tr>";
                            while(i < data.p.length){
                                str += '<tr class="mySub"><td style="color:#2980b9;">'+(i+1)+'</td><td style="color:#2980b9;">'+data.q[i]+'</td><td style="color:#2980b9;">'+data.s[i]+'</td><td style="color:#2980b9;">'+data.r[i]+'</td></tr>';
                                i++;
                            }
                            $("#soidSearchTable > tbody > tr").eq(rowIndex).after(str);
                            $(".subTable").dataTable();*/
                            th.attr("call","f");
                            $(".expandCls",th).removeClass("fa-plus-circle").addClass("fa-minus-circle");
                            var numCols = $("#soidSearchTable").find('tr')[0].cells.length;
                            var i = 0;str = '<tr class="subTableRow"><td style="text-align:-webkit-center;" colspan="'+numCols+'"><div class="row" style="width:65% !important;"><table class="table subTableS"><thead><tr><th>Sno</th><th style="text-align:left !important;">Product</th><th>Order Qty</th><th>Supply Qty</th></tr></thead><tbody>';
                            while(i < data.p.length){
                                str += '<tr><td class="text-center">'+(i+1)+'</td><td style="text-align:left !important;">'+data.q[i]+'</td><td class="text-center">'+data.s[i]+'</td><td class="text-center">'+data.r[i]+'</td></tr>';
                                i++;
                            }
                            str += "</tbody></table></div></td></tr>";
                            $("#soidSearchTable > tbody > tr").eq(rowIndex).after(str);
                            $(".subTableS").DataTable({
                                "aPaginate":false,
                                "bInfo" : false,
                                "bAutoWidth" : false
                            });
                            $(".subTableRow .dataTables_length").hide();
                        } else {
                            MyError_msg();$('.errorMsg').text("Dear customer, Unable to get search records, please try later");
                        }
                        $('.overlay_load').fadeOut();
                    },
                    error: function(xhr, status, error) {
                        MyError_msg();$('.errorMsg').text(serverBusyError);
                        $('.overlay_load').fadeOut();
                    }
                });
            }
            $("#soidSearchTable > tbody > tr").each(function(){
                if($(this).attr("call") == "f") {
                    $(this).attr("call","t");
                    $(".expandCls",this).removeClass("fa-minus-circle").addClass("fa-plus-circle");
                }
                $(".subTableRow").remove();
            });
        });
        function searchRwService(param,th,ordDate,billNo,ordNo){
            $('.overlay_load').fadeIn();
            $.ajax({
                data: param,
                url : 'http://'+ip+'/ThillaisServices/rest/so/WantedNotesalesOrderInformation',
                type : 'POST',
                dataType: 'json',
                global: true,
                success: function(data) {
                    var bill_No;
                    $(".custNamePOP").text(logCustName()+" ("+ordDate+")");
                    if (billNo == "" ) {
                        bill_No = "<div style='color:red;'>N/A</div>";
                    } else {
                        bill_No = billNo;
                    }
                    if(data) {
                        var str = '<div class="x_content card-box table-responsive"><div class="row"><div class="col-md-12 bor_bottom"><div class="col-md-4 bor_right"> <span class="leftSpan">Order No</span> <span class="rightSpan orderNoPOPSearch x-pad">'+ordNo+'</span></div><div class="col-md-4 bor_right"> <span class="leftSpan">Date</span> <span class="rightSpan x-pad">'+ordDate+'</span></div><div class="col-md-4"> <span class="leftSpan">Total</span> <span class="rightSpan x-pad"><i class="fa fa-inr" aria-hidden="true"></i> '+data.h+'</span></div></div></div> <br><div class="row"><div class="col-md-12 bor_bottom"><div class="col-md-4 bor_right"> <span class="leftSpan">Distributor Details</span> <span class="rightSpan x-pad">'+data.a1+'</span></div><div class="col-md-4"> <span class="leftSpan">Bill No</span> <span class="rightSpan x-pad">'+bill_No+'</span></div><div class="col-md-4"></div></div></div></div><div class="col-md-12 x_panel padding20 padBord10 tableHeight350"><table class="table table-hover"><thead><tr><th>Sno</th><th>Product</th><th>Order Qty</th><th>Supply Qty</th></tr></thead><tbody>';
                        var i = 0;
                        while(i < data.p.length){
                            str += '<tr><td>'+(i+1)+'</td><td>'+data.q[i]+'</td><td>'+data.s[i]+'</td><td>'+data.r[i]+'</td></tr>';
                            i++;
                        }
                        str += '</tbody></table></div>';
                        $(".soSearchPOP").html(str);
                        $("#soidSearchDetails").modal("show");
                    } else {
                        MyError_msg();$('.errorMsg').text("Dear customer, Unable to get search records, please try later");
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                    $('.overlay_load').fadeOut();
                }
            });
        }
        $(document).on("click",".searchRowClk, .rowOrderView",function(){
            var th;
            if($("#retailerSearchHidden").val()) {
                if($(this).hasClass("searchRowClk")) {
                    th = $(this).parent();
                } else th = $(this).parent().parent();
                $('.overlay_load').fadeIn();
                var ordDate = $(".orderDateSearchRow",th).val();
                var billNo = $(".distBillSearchRow",th).val();
                var ordNo = $(".orderNoSearchRow",th).val();
                var param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:$("#retailerSearchHidden").val(),entityId:$(".distIdSearchRow",th).val(),soid:$(".orderNoSearchRow",th).val(),userRole:localStorage.getItem("userRole")}
                searchRwService(param,th,ordDate,billNo,ordNo);
            } else {
                MyError_msg();$('.errorMsg').text("Please select Retailer");
                $("#retailerSearch").focus();
            }
        });
        $('#orderSuccessModal').on('hidden.bs.modal', function () {
            $("#clearALLbtn").click();
            //$("#productsDivsHide").slideUp();
            $("#productsSearch").focus();
        });
        $("#orderTab").click(function() {
            $("#productsSearch").val("").focus();
        });
        $(document).on("keydown", function(event) {//$('#myTab a[href="#tab_content1"]').tab('show');
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if(keycode == '118'){
                if($("#orderTab").hasClass("active")) {
                    if($('.modal-dialog').parent().hasClass("in")) {
                        
                    } else {
                        $("#plcOrderBTN").click();
                    }
                }
            }
        });
        $(document).on("click","#plcOrderBTN",function(){
            if($("#retailerAddHidden").val()){
                var ths = $(this);
                var requisition_data = [];row = 1;
                $("#selectedProducts > tbody > tr").each(function(){
                    if($(".pcode_Hidden").val() && $('.lineTotHiddden',this).val() > 0) {
                        requisition_data.push({
                            qty : $(".qtySelProdct",this).text(),
                            sellingPrice : $(".sp_Hidden",this).val(),
                            lineNo : row,
                            childvendorList : $(".Schild_vendor",this).val(),
                            parentvendorList : $(".Sparent_vendor",this).val(),
                            product : $(".pcode_Hidden",this).val(),  
                            prodDescr : $(".prdDescSele",this).text(),
                            batch : $(".btchID_Hidden",this).val()
                        });
                        row++;
                    } 
                });
                if(requisition_data.length > 0) {
                    $('.overlay_load').fadeIn();
                    var orderSource = "";
                    if(localStorage.getItem("userRole") == 9){
                        orderSource = "wn.s.web";
                    } else if(localStorage.getItem("userRole") == 10){
                        orderSource = "wn.web";
                    }
                    var param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:$("#retailerAddHidden").val(),requisition_data : requisition_data,orderSource:orderSource};
                    $.ajax({
                        data: param,
                        url : 'http://'+ip+'/ThillaisServices/rest/req/wantedOrderCreationWeb',
                        type : 'POST',
                        dataType: 'json',
                        global: true,
                        success: function(data) {
                            if(data) {
                                if(data.R == "SUCCESS") {
                                    var orders = "";i = 0;sno = 1;
                                    while(i < data.S.length) {
                                        orders += data.S[i]+", ";
                                        i++
                                    }
                                    ths.attr("orderNum",orders.slice(0,-2));    //remove last , and space
                                    $(".custNamePOP").text(logCustName());
                                    var str = '<div class="x_content card-box table-responsive"><div class="row"><div class="col-md-12 bor_bottom"><div class="col-md-4 bor_right"> <span class="leftSpan">Order No</span> <span class="rightSpan orderNoPOP x-pad">'+orders.slice(0,-2)+'</span></div><div class="col-md-4 bor_right"> <span class="leftSpan">Date</span> <span class="rightSpan x-pad">'+todayDate+'</span></div><div class="col-md-4"> <span class="leftSpan">Total</span> <span class="rightSpan x-pad"><i class="fa fa-inr" aria-hidden="true"></i> '+$(".totTab .distWiseGtotal").text()+'</span></div></div></div> <br><div class="col-md-12 padding20 padBord10 tableHeight350"><table class="table table-hover" id="orderSuccTable"><thead><tr><th>Sno</th><th>Product</th><th>Distributor</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>';
                                    $('#selectedProducts > tbody >tr').each(function(){
                                        if($('.pcode_Hidden',this).val()) { 
                                            if($('.lineTotHiddden',this).val() > 0) {
                                                str = str + '<tr><td>'+sno+'</td><td>'+$('.prdDescSele',this).text()+'</td><td>'+$('.distSel',this).text()+'</td><td>'+$('.qtySelProdct',this).text()+'</td><td>'+$('.sp_Hidden',this).val()+'</td><td>'+$('.lineTotHiddden',this).val()+'</td></tr>';
                                                sno++;
                                            }
                                        }
                                    });
                                    str += '</tbody></table></div></div>';
                                    $(".orderMODAL").html(str);
                                    $("#orderSuccessModal").modal("show");
                                    MySuccess_msg(); $('.successMsg').text('Dear customer, Your Order was Successfully placed, Order Number(s) : '+orders.slice(0,-2));
                                    countService();
                                } else {
                                    MyError_msg(); $('.errorMsg').text('Unable to create order, Please try again after some time');
                                }
                            } else {
                                MyError_msg();$('.errorMsg').text("Unable to create order, Please try again after some time");
                            }
                            $('.overlay_load').fadeOut();
                        },
                        error: function(xhr, status, error) {
                            MyError_msg();$('.errorMsg').text(serverBusyError);
                            $('.overlay_load').fadeOut();
                        }
                    });
                } else {
                    MyError_msg(); $('.errorMsg').text('Please select atleast one product to place order');
                    $("#productsSearch").val("");
                    $("#productsSearch").focus();
                }
            } else {
                MyError_msg(); $('.errorMsg').text('Please select Retailer');
                $("#productsSearch").val("");
                $("#retailerInput").focus();
            }
        });
        $(document).on('click','#printord_search', function() {
            $('.x_content').css('overflow-x', 'hidden');
            $('.orderSearchprint').print({
                //Use Global styles 
                globalStyles: false,
                //Add link with attrbute media=print
                mediaPrint: false,
                //Custom stylesheet
                stylesheet: "MyAssets/css/printCSS.css",
                //stylesheet: "assets/css/custom_1.0.6.css",
                //Print in a hidden iframe
                iframe: true,
                //Don't print this
                noPrintSelector: ".avoid-this"
            });
            $('.x_content').removeAttr('style');
        });
        $(document).on('click','#printplaceord', function() {
            $('.x_content').css('overflow-x', 'hidden');
            $('#placeorderprint').print({
                //Use Global styles 
                globalStyles: false,
                //Add link with attrbute media=print
                mediaPrint: false,
                //Custom stylesheet
                stylesheet: "MyAssets/css/printCSS.css",
                //stylesheet: "assets/css/custom_1.0.6.css",
                //Print in a hidden iframe
                iframe: true,
                //Don't print this
                noPrintSelector: ".avoid-this"
            });
            $('.x_content').removeAttr('style');
        });
        $("#retailerInput, #productsSearch, #retailerSearch, #distributorSearch").on( "autocompleteclose", function( event, ui ) {
            $(".ui-autocomplete li").each(function(){
                $(this).remove();
            });
        })
        $("#reorderBtn").click(function(){
            //$("#clearALLbtn").click();
            $("#DistWiseTot > tbody").show();
            $('.overlay_load').fadeIn();
            $.ajax({
                data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),orderNo:$(".orderNoPOPSearch").text(),roleNo:localStorage.getItem("userRole")},
                url : 'http://'+ip+'/ThillaisServices/rest/req/WnReorder',
                type : 'POST',
                dataType: 'json',
                global: true,
                success: function(data) {
                    if(data){
                        $("#draftIDpgLvl").val("");
                        if(data.length != 0) {
                            //$("#productsSearch",).autocomplete( "destroy" );
                            /*if(localStorage.getItem("userRole") == 9){
                                $("#retailerInput").autocomplete("search",$("#retailerSearchHidden").val());
                                $("#retailerInput").on( "autocompleteopen", function( event, ui ) {
                                    $(".ui-autocomplete li").click();
                                } );
                            }*/
                            var str = "";
                            $.each(data,function(ind,ele){
                                $('.optWrapper ul li',$("#distributorsInput").parent()).each(function(){
                                    var dist_ = $(this).attr('data-val');
                                    if(dist_ == ele.l){
                                        if($(this).hasClass("selected")){

                                        } else {
                                            $(this).trigger('click');
                                        }
                                    }
                                });
                                $("#DistWiseTot > tbody > tr").each(function(){
                                    if($(this).hasClass("d_sN")) {
                                        $(this).removeClass("d_sN");
                                    }
                                    if(ele.l == $('.disIdDistWiseT',this).val()) {
                                        $('.prodtsDistWiseT',this).text(parseInt($('.prodtsDistWiseT',this).text())+1);
                                        var lineTotal = ele.m*ele.g;
                                        var tableLinesSum = parseFloat($('.TotDistWiseT',this).text());
                                        $('.TotDistWiseT',this).text(parseFloat(lineTotal+tableLinesSum).toFixed(2));
                                    }
                                }); 
                                var thisVenId = ele.l;spDisplay = "";
                                var reqSelected = localStorage.getItem("SDList");
                                //console.log(" ele "+ele.manufName);
                                $.each(JSON.parse(reqSelected), function(index, element) {
                                    if(thisVenId == element.value) {
                                        function flagBased() {
                                            if (element.PriceFlag == "true" || element.PriceFlag == "")
                                                spDisplay = ele.g;
                                            else spDisplay = "A";
                                        }
                                        function onlyAvailable(){
                                            spDisplay = "A";
                                        }
                                        if(element.minStkflag == "true"){
                                            if(element.BothStockFlag == "true"){ //less - true, both - true
                                                flagBased();
                                            } else {  //less - true, both - false
                                                onlyAvailable();
                                            }
                                        } else {
                                            if(element.BothStockFlag == "true") { //less - false, both - true
                                                flagBased();
                                            } else {  //less - false, both - false
                                                onlyAvailable();
                                            }
                                        }
                                        if(element.minStkflag == "") {
                                            if (element.BothStockFlag == ""){
                                                flagBased();
                                            } else if(element.BothStockFlag == "true") {
                                                flagBased();
                                            } else if(element.BothStockFlag == "false") {
                                                onlyAvailable();
                                            }
                                        } else if(element.minStkflag == "true") {
                                            if(element.BothStockFlag == "") {
                                                spDisplay = ele.g;
                                            }
                                        } else if(element.minStkflag == "false") {
                                            if(element.BothStockFlag == "") {
                                                spDisplay = ele.g;
                                            }
                                        }
                                        if(element.stockFlag == "" && element.MrpFlag == "" && element.PriceFlag == "" && element.OfferFlag == "" && element.MfgrFlag == "" && element.minStkflag == "" && element.BothStockFlag == ""){
                                            spDisplay = ele.g;
                                        }  
                                    }
                                });
                                str += "<tr><td class='num'></td><td class='prdDescSele'><input type='hidden' class='stock_Hidden' value='"+ele.h+"'><input type='hidden' class='sp_Hidden' value='"+ele.g+"'><input type='hidden' class='pcode_Hidden' value='"+ele.c+"'><input type='hidden' class='pVendor_Hidden' value='"+ele.l+"'><input type='hidden' class='Sparent_vendor' value='"+ele.l+"'><input type='hidden' class='childID_Hidden' value='"+ele.a+"'><input type='hidden' class='Schild_vendor' value='"+ele.a+"'><input type='hidden' class='btchID_Hidden' value='"+ele.e+"'><input type='hidden' class='lineTotHiddden' value='"+parseFloat(ele.m*ele.g).toFixed(2)+"'>"+ele.d+"</td><td class='distSel'>"+ele.b+"</td><td class='qtySelProdct'>"+ele.m+"</td><td class='txtBold' style='color:#00BFFF'>"+spDisplay+"</td><td class='txtBold' style='color:#2980b9'><span class='totalsumRW'>"+parseFloat(ele.m*ele.g).toFixed(2)+"</span></td><td><a class='btn btn-danger btn-xs clearROW' style='font-size: 11px;'><i class='fa fa-trash-o'></i></a></td></tr>";
                            });
                            $("#selectedProducts > tbody").html(str);
                            $("#DistWiseTot > tbody > tr").each(function(){
                                if($('.prodtsDistWiseT',this).text() == 0) {
                                    if(!$(this).hasClass("d_sN")) {
                                        $(this).addClass("d_sN");
                                    }
                                }
                            });
                            //summary limit code starts
                            if(localStorage.getItem("userRole") != 9) {
                                $.each(data,function(ind,ele){
                                    var thisVenId = ele.l;
                                    var limit="";distr_i="";dist_to="";dis="";
                                    //var Totval = parseFloat(data.i[ij]*data.h[ij]).toFixed(2);
                                    var summTot = 0;
                                    $("#DistWiseTot > tbody > tr").each(function(){
                                        if(!$(".distrDesc span",this).hasClass("d_sN")) {
                                            $(".distrDesc span",this).addClass("d_sN");
                                            $(this).removeClass("c_pointer").removeAttr("title");
                                        }
                                        if(!$(this).hasClass("d_sN")) {
                                            if(thisVenId == $('.disIdDistWiseT',this).val()){
                                                summTot += $('.TotDistWiseT',this).text();
                                            }
                                        }
                                    });
                                    var limitsel = localStorage.getItem("SDList");
                                    $.each(JSON.parse(limitsel), function(index, elem) {
                                       if(elem.value == thisVenId){
                                        limit = elem.limitFlag;
                                       }
                                    });
                                    if(limit != 0) {
                                        if($("#DistWiseTot > tbody > tr:not('.d_sN')").length) {
                                            if(Math.round(limit * 100) > Math.round(summTot * 100)){
                                                //$("span",$("#DistWiseTot > tbody > tr > .distrDesc")).addClass("d_sN");
                                            } else {
                                                $("#DistWiseTot > tbody > tr").each(function(){
                                                    if(!$(this).hasClass("d_sN")) {
                                                        if(thisVenId == $('.disIdDistWiseT',this).val()){
                                                            $(".distrDesc span",this).removeClass("d_sN");
                                                            $(this).attr("title","Your limit is crossed (Rs. "+$(".limitSummHidn",this).val()+")").addClass("c_pointer");
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    }
                                });
                            }
                            //summary limit code ends
                            updateSlnoPrdcts();
                            selPrdGrandTOT();
                            $("#soidSearchDetails").modal("hide");
                            $('#myTab a[href="#tab_content1"]').tab('show');
                            $("#retailerAddHidden").val($("#retailerSearchHidden").val());
                            $("#retailerInput").val($("#retailerSearch").val());
                            $("#retailerInput").attr("original_name",$("#retailerSearch").val());
                        } else {
                            MyError_msg();$('.errorMsg').text("Dear customer, There is no records to order again");
                        }
                    } else {
                        MyError_msg();$('.errorMsg').text("Dear customer, Unable to get records, please try later");
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                    $('.overlay_load').fadeOut();
                }
            });
        });
        $(document).on("click",".rowCSVDwnld, #csvDnldPOP",function(){
            $('.overlay_load').fadeIn();
            var soID = "";
            if($(this).hasClass("rowCSVDwnld")) {
                soID = $(".orderNoSearchRow",$(this).parent().parent().parent().parent().parent()).val()
            } else {
                if($(this).attr("id") == "csvDnldPOP"){
                    soID = $(".orderNoPOPSearch").text();
                }
            }
            $.ajax({
                data: {userid : localStorage.getItem("userid"),password : localStorage.getItem("pwd"),soId:soID},
                url : 'http://'+ip+'/ThillaisServices/rest/products/soDownlaodDetailsforRetailorWeb',
                type : 'POST',
                dataType: 'json',
                global: true,
                success: function(data) {
                    if(data) {
                        var csvName = $('#retailerInput').val()+"_"+soID;
                        JSONToCSVConvertor(JSON.stringify(data), csvName, true);
                    } else {
                        MyError_msg();$('.errorMsg').text("Sorry, No details found to Download");
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                    $('.overlay_load').fadeOut();
                }
            });
        });
        $(document).on("click",".rowCSVDwnld2, #csvDnldPOP2",function(){
            $('.overlay_load').fadeIn();
            var soID = "";
            if($(this).hasClass("rowCSVDwnld2")) {
                soID = $(".orderNoSearchRow",$(this).parent().parent().parent().parent().parent()).val()
            } else {
                if($(this).attr("id") == "csvDnldPOP2"){
                    soID = $(".orderNoPOPSearch").text();
                }
            }
            $.ajax({
                data: {userid : localStorage.getItem("userid"),password : localStorage.getItem("pwd"),soId:soID},
                url : 'http://'+ip+'/ThillaisServices/rest/products/csvDownloadFormat2',
                type : 'POST',
                dataType: 'json',
                global: true,
                success: function(data) {
                    if(data && data.length != 0){
                        var csvName = $('#retailerSearch').val()+"_"+soID;
                        JSONToCSVConvertor(JSON.stringify(data), csvName, true);
                        $('.overlay_load').fadeOut();
                    } else {
                        $('.overlay_load').fadeOut();
                        MyError_msg(); $('.errorMsg').text("Sorry, No Product details available to download");
                    }
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                    $('.overlay_load').fadeOut();
                }
            });
        });     
        $(document).on('click','.offerNotLI .info-number', function() {
            if($(".offerNotLI").hasClass("open")) {
                $(".offerNotLI .dropdown-menu").html("<li><a><span class=message>Loading, Please wait. . .</span></a>");
                var a = "";
                if(localStorage.getItem("userRole") == 9) {
                    a = "S-WEB";
                } else if(localStorage.getItem("userRole") == 10) {
                    a = "R-WEB";
                }
                $.ajax({
                    data: {n:a},
                    url : 'http://'+ip+'/ThillaisServices/rest/web/WN_OFFER',
                    type : 'POST',
                    dataType: 'json',
                    global: true,
                    success: function(data) {
                        if(data) {
                            $(".offerNotLI .badge").text(data.a.length)
                            var i = 0;str = "";
                            while(i < data.a.length) {
                                str += "<li><a><span class='message'>"+data.a[i]+"</span></a>";
                                i++;
                            }
                            $(".offerNotLI .dropdown-menu").html(str);
                        } else {
                            MyError_msg();$('.errorMsg').text("Dearcustomer, Failed to get Offer Details");
                        }
                        $('.overlay_load').fadeOut();
                    },
                    error: function(xhr, status, error) {
                        MyError_msg();$('.errorMsg').text(serverBusyError);
                        $('.overlay_load').fadeOut();
                    }
                });
            }
        });
        $(document).on('click','.nificationLI .info-number', function() {
            if($(".nificationLI").hasClass("open")) {
                $(".nificationLI .dropdown-menu").html("<li><a><span class=message>Loading, Please wait. . .</span></a>");
                var a = "";
                if(localStorage.getItem("userRole") == 9) {
                    a = "S-WEB";
                } else if(localStorage.getItem("userRole") == 10) {
                    a = "R-WEB";
                }
                $.ajax({
                    data: {u:localStorage.getItem("userid"),s:a},
                    url : 'http://'+ip+'/ThillaisServices/rest/web/WEB_NOTIFICATION',
                    type : 'POST',
                    dataType: 'json',
                    global: true,
                    success: function(data) {
                        if(data) {
                            var i = 0;str = "";
                            $(".nificationLI .badge").text(data.a.length);
                            while(i < data.a.length) {
                                str += "<li data-val='"+data.a[i]+"' distID='"+data.c[i]+"' oDate='"+data.e[i]+"' oBill='"+data.d[i]+"'><a><span class='message'>"+data.b[i]+"</span></a>";
                                i++;
                            }
                            $(".nificationLI .dropdown-menu").html(str);
                        } else {
                            MyError_msg();$('.errorMsg').text("Dear customer, Failed to load notifications");
                        }
                    },
                    error: function(xhr, status, error) {
                        MyError_msg();$('.errorMsg').text(serverBusyError);
                        $('.overlay_load').fadeOut();
                    }
                });
            }
        });
        $(document).on('click','.nificationLI .dropdown-menu li', function() {
            if($(this).attr("data-val")) {
                if($("#retailerAddHidden").val()){
                    var param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),customerId:$("#retailerAddHidden").val(),entityId:$(this).attr("distID"),soid:$(this).attr("data-val"),userRole:localStorage.getItem("userRole")}
                    searchRwService(param,"",$(this).attr("oDate"),$(this).attr("oBill"),$(this).attr("data-val"));
                    //searchRwService(param,th,ordDate,billNo,ordNo);
                    $('#myTab a[href="#tab_content2"]').tab('show');
                } else {
                    MyError_msg();$('.errorMsg').text("Please select retailer");
                    $("#retailerInput").val("").focus();
                }
            }
        });
    }  else if(currentPName == "retailer_profile") {
        $("#pCntctNo").val(localStorage.getItem("userid"));
        $.ajax({
            data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd")},
            url : 'http://'+ip+'/ThillaisServices/rest/req/getWebUserEntity',
            type : 'POST',
            dataType: 'json',
            success: function(data) {
                if(data && data.length != 0){
                    var profileTags = [];
                    $.each(data, function(index, element) {
                        if(element.a) {
                            profileTags.push({
                                label: element.b.trim()+", "+element.c.trim(),
                                value: element.a,
                                retName: element.b.trim()
                            });
                        }
                    });
                    $("#cntctperson").autocomplete({
                        appendTo: '#retProfile',
                        source: profileTags,
                        focus : function(event,ui) {
                            event.preventDefault();
                        },
                        select : function(event,ui) {
                            event.preventDefault();
                            $(this).val(ui.item.retName);
                            $(this).prev().val(ui.item.value);
                            $(this).attr('retName',ui.item.retName);
                            $(this).prev().attr('original_hidden',ui.item.value);
                            $(this).attr('original_name',ui.item.retName);
                        }
                    }).bind('focus', function(){ $(this).autocomplete("search"," "); } );
                                        $('#cntctperson').focus();
                    //$("#profcntctperson").focus();
                    if(profileTags.length == 1) {
                        $("#cntctperson").val(profileTags[0].retName);
                        $("#cntperHidd").val(profileTags[0].value);
                        $("#cntctperson").attr('retName',profileTags[0].retName);
                        $("#cntperHidd").prev().attr('original_hidden',profileTags[0].retName);
                        $("#cntctperson").attr('original_name',profileTags[0].label);
                    } else {
                        //$("#cntctperson").focus();
                    }
                    $('.overlay_load').fadeOut();
                } else {
                    $('.overlay_load').fadeOut();
                    MyError_msg(); $('.errorMsg').text("Dear customer, Faild to get retailer details, please try later ");
                }
            },
            error: function(xhr, status, error) {
                $('.overlay_load').fadeOut();
                MyError_msg();$('.errorMsg').text(serverBusyError);
            }
        });
        $("#retProfile").modal("show");
        $('#retProfile').on('shown.bs.modal', function () {
            $("#cntctperson").focus();
        });
        //$(document).on("focus","#cntctperson",function(){
            
        //});
        $("#remindMeLtr").click(function(){
            window.location.href = "place_order.html";
        });
        $("#altCno").keypress(function (e) {
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                MyError_msg(); $('.errorMsg').text('Please enter numerics only');
                $('#altCno').focus();
                return false;
            }
        });
        $("#pincode").keypress(function (e) {
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                MyError_msg(); $('.errorMsg').text('Please enter numerics only');
                $('#pincode').focus();
                return false;
            }
        });
        var readOnlyLength_altCno = $('#altCno').val().length;
        $('#altCno').on('keypress, keydown', function(event) {
            var $field = $(this);
            if ((event.which != 37 && (event.which != 39))
                && ((this.selectionStart < readOnlyLength_altCno)
                || ((this.selectionStart == readOnlyLength_altCno) && (event.which == 8)))) {
                return false;
            }
        });
        $(function() {
            $("#YOE_").datepicker({
                maxDate:0,
                dateFormat: 'yy-mm-dd'
            });
        });
        function submitService () {
            $('.overlay_load').fadeIn();
            var altNUM = "";
            if(mobNoFun_($("#altCno").val()) == "91") {
                altNUM = "";
            } else {
                altNUM = mobNoFun_($("#altCno").val());
            }
            var param = {userid : localStorage.getItem("userid"),pwd : $('#current_pswd').val(),contact_person : $("#cntctperson").attr("retname"),Primary_Contact_no :$("#pCntctNo").val(),Drug_License_no : $("#DL_no").val(),tin : $("#TIN_no").val(),email:$("#email").val(),EOY:$("#YOE_").val(),FinancialAssistent:$("#yesNoSelect").val(),AvgSales:$("#avgSales").val(),entityId : $("#cntperHidd").val(),alternateName:$("#altName").val(),alternateNo:altNUM,pincode:$("#pincode").val(),primary_contact_name:$("#pCntctName").val()};
            $.ajax({
                data: param,
                url : 'http://'+ip+'/ThillaisServices/rest/web/WnRetailerProfile',
                type : 'POST',
                dataType: 'json',
                success: function(data) {
                    if(data.Result == 'SUCCESS') {  
                        localStorage.setItem("flashMsg","Profile details submitted successfully");
                        window.location.href = "place_order.html";    
                    } else {
                        MyError_msg(); $('.errorMsg').text('Failed to submit profile details, Please contact Admin ');
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();
                    $('.errorMsg').text(serverBusyError);$('.overlay_load').fadeOut();
                }
            });
        }
        $("#rProfSubmit").click(function(){
            if($("#cntperHidd").val()){
                if($("#pCntctName").val()){
                    if($("#DL_no").val()){
                        if($("#yesNoSelect").val()) {
                            if($("#yesNoSelect").val() == "Yes"){
                                if($("#YOE_").val()) {
                                    if($("#avgSales").val()) {
                                        submitService();
                                    } else {
                                        $("#avgSales").focus();
                                        MyError_msg(); $('.errorMsg').text('Please enter Average Sales Per Month');
                                    }
                                } else {
                                    $("#YOE_").focus();
                                    MyError_msg(); $('.errorMsg').text('Please select Year Of Establishment (YOE)');
                                }
                            } else if($("#yesNoSelect").val() == "No") {
                                submitService();
                            }
                        } else {
                            $("#yesNoSelect").focus();
                            MyError_msg(); $('.errorMsg').text('Please select an Option for "Would you be interested in Financial Assistance"');
                        }
                    } else {
                        $("#DL_no").focus();
                        MyError_msg(); $('.errorMsg').text('Please enter Drug License No');
                    }
                } else{
                    $("#pCntctName").focus();
                    MyError_msg(); $('.errorMsg').text('Please enter Primary Contact Name');
                }
            } else{
                $("#cntctperson").focus();
                MyError_msg(); $('.errorMsg').text('Please select Retailer Name');
            }
        });
    } else if(currentPName == "change_password") {
        $('.overlay_load').fadeOut();
        $("#mobileForOTP").keypress(function (e) {
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                MyError_msg(); $('.errorMsg').text('Please enter numerics only');
                $('#mobileForOTP').focus();
                return false;
            }
        });
        var readOnlyLength = $('#mobileForOTP').val().length;
        $('#mobileForOTP').on('keypress, keydown', function(event) {
            var $field = $(this);
            if ((event.which != 37 && (event.which != 39))
                && ((this.selectionStart < readOnlyLength)
                || ((this.selectionStart == readOnlyLength) && (event.which == 8)))) {
                return false;
            }
        });
        $('#mobileForOTP').val($('#mobileForOTP').val());
        $('#mobileForOTP').focus();
        $("#pswdChange_details_trigger").click();
        $('#getOTPbtn').click(function(){
            if($("#mobileForOTP").val().length > 5){
                if($("#mobileForOTP").val().length == 15){
                    if(/^(91(\s*[\ -]\s*)?|[0]?)?[789]\d{9}$/.test($("#mobileForOTP").val())){
                        $('.overlay_load').fadeIn();
                        $.ajax({
                            data: {userid : localStorage.getItem("userid"),mob : mobNoFun_($('#mobileForOTP').val())},
                            url : 'http://'+ip+'/ThillaisServices/rest/web/SendOTP',
                            type : 'POST',
                            dataType: 'json',
                            success: function(data) {
                                if(data.RESULT == 'Sucess'){
                                    $(".otpDIV").hide();
                                    $("#otpHidden").val($("#mobileForOTP").val());
                                    $(".passwordDIV").show();
                                    $("#userOTP").html("Your OTP sent successfully to "+$("#mobileForOTP").val())
                                    MySuccess_msg();
                                    $('.successMsg').text('Dear Customer OTP sended successfully to '+$("#mobileForOTP").val());
                                } else {
                                    $('#mobileForOTP').focus();
                                    MyError_msg(); $('.errorMsg').text('Sorry, Failed to get OTP, Please try after some time');
                                }
                                $('.overlay_load').fadeOut();
                            },
                            error: function(xhr, status, error) {
                                $('.overlay_load').fadeOut();
                                MyError_msg();
                                $('.errorMsg').text(serverBusyError);
                            }
                        });
                    } else{
                        $("#mobileForOTP").focus();
                        MyError_msg(); $('.errorMsg').text('Please enter Mobile No Starting with 7 or 8 or 9');
                    }
                } else {
                    $("#mobileForOTP").focus();
                    MyError_msg(); $('.errorMsg').text('Please enter your 10 digits Mobile Number');
                }
            } else {
                var SearchInput = $('#mobileForOTP');
                SearchInput.val(SearchInput.val());
                SearchInput.focus();
                MyError_msg(); $('.errorMsg').text('Please enter Mobile Number');
            }
        });
        $('#change_pswd').click(function(){
            var err = '<i class="icon-close" aria-hidden="true" style="color:red;padding-left: 5px;font-size:10px;"></i>';
            var succ = '<i class="icon-checkmark3" aria-hidden="true" style="font-size:12px;"></i>';
            var thsVal = $('#new_pswd').val();
            var regExpr = /(?=.*\d)(?=.*[A-Z])/;
            if($('#new_pswd').val()){
                if($('#new_pswd').val().length >= 6) {
                    $("#pswdLenInfo").html(succ);
                    if(regExpr.test(thsVal)) {
                        $("#pswdLetrChk").html(succ);
                        if($('#repeat_pswd').val()){
                            if($('#new_pswd').val() == $('#repeat_pswd').val()){
                                if($('#otpPSWDpopup').val()) {
                                    $('.overlay_load').fadeIn();
                                    var param = {userid : localStorage.getItem("userid"),otp : $('#otpPSWDpopup').val(), mob:mobNoFun_($('#otpHidden').val()),newpassword : $('#new_pswd').val(),source :$('#SourcePSWD').val()};
                                    $.ajax({
                                      data: param,
                                      url : 'http://'+ip+'/ThillaisServices/rest/web/WnChangePassword',
                                      type : 'POST',
                                      dataType: 'json',
                                      success: function(data) {
                                          if(data.R == 'Y'){
                                              localStorage.setItem("pwd",$('#new_pswd').val());  
                                              localStorage.setItem("flashMsg","Dear Customer, Your password changed successfully.");
                                                window.location.href = "place_order.html";
                                          } else {
                                                $('#otpPSWDpopup').val("");
                                                $('#otpPSWDpopup').focus();
                                                MyError_msg(); $('.errorMsg').text('Dear customer, Failed to change your password (Invalid OTP).');
                                          }
                                          $('.overlay_load').fadeOut();
                                      },
                                      error: function(xhr, status, error) {
                                          MyError_msg();
                                          $('.errorMsg').text(serverBusyError);
                                      }
                                    });
                                } else {
                                    $('#otpPSWDpopup').focus();$('.overlay_load').fadeOut();
                                    MyError_msg(); $('.errorMsg').text('Please Enter OTP (Already you have recieved to '+$('#otpHidden').val()+' )');
                                }
                            } else {
                                $("#pswdLenInfo").html(err);
                                $("#pswdLetrChk").html(err);
                                $('#new_pswd').val('');
                                $('#repeat_pswd').val('');
                                $('#new_pswd').focus();
                                MyError_msg(); $('.errorMsg').text('The passwords you have entered does not match, Please re-Enter');
                            }
                        } else {
                            $('#repeat_pswd').focus();
                            MyError_msg(); $('.errorMsg').text('Please re-enter new password');
                        }
                    } else {
                        $('#new_pswd').focus();
                        $("#pswdLetrChk").html(err);
                        MyError_msg(); $('.errorMsg').text('Password must contain at least one Number and one Uppercase letter');
                    }
                } else {
                    $('#new_pswd').focus();
                    $("#pswdLenInfo").html(err);
                    MyError_msg(); $('.errorMsg').text('Password must contain at least six characters!');
                }
            } else {
                $('#new_pswd').focus();
                $("#pswdLenInfo").html(err);
                MyError_msg(); $('.errorMsg').text('Please enter new password');
            }
        });
    } else if(currentPName == "profile") {
        $("#pCntctNo").val(localStorage.getItem("userid"));
        $("#retProfile").modal("show");
        $.ajax({
            data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd")},
            url : 'http://'+ip+'/ThillaisServices/rest/req/getWebUserEntity',
            type : 'POST',
            dataType: 'json',
            success: function(data) {
                if(data && data.length != 0){
                    var profileTags = [];
                    $.each(data, function(index, element) {
                        if(element.a) {
                            profileTags.push({
                                label: element.b.trim()+", "+element.c.trim(),
                                value: element.a,
                                retName: element.b.trim()
                            });
                        }
                    });
                    $("#profcntctperson").autocomplete({
                        source: profileTags,
                        focus : function(event,ui) {
                            event.preventDefault();
                        },
                        select : function(event,ui) {
                            event.preventDefault();
                            $(this).val(ui.item.label);
                            $(this).prev().val(ui.item.value);
                            $(this).attr('retName',ui.item.retName);
                            $(this).prev().attr('original_hidden',ui.item.value);
                            $(this).attr('original_name',ui.item.label);
                        }
                    }).bind('focus', function(){ $(this).autocomplete("search"," "); } );
                    //$("#profcntctperson").focus();
                    if(profileTags.length == 1) {
                        $("#profcntctperson").val(profileTags[0].label);
                        $("#cntctpersonhidden").val(profileTags[0].value);
                        $("#profcntctperson").attr('retName',profileTags[0].retName);
                        $("#cntctpersonhidden").prev().attr('original_hidden',profileTags[0].value);
                        $("#profcntctperson").attr('original_name',profileTags[0].label);
                    } else {
                        $("#profcntctperson").focus();
                    }
                    $('.overlay_load').fadeOut();
                } else {
                    $('.overlay_load').fadeOut();
                    MyError_msg(); $('.errorMsg').text("Dear customer, Faild to get retailer details, please try later ");
                }
            },
            error: function(xhr, status, error) {
                $('.overlay_load').fadeOut();
                MyError_msg();$('.errorMsg').text(serverBusyError);
            }
        });
        $("#altCno, #pincode").keypress(function (e) {
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                MyError_msg(); $('.errorMsg').text('Please enter numerics only');
                return false;
            }
        });
        var readOnlyLength_altCno = $('#altCno').val().length;
        $('#altCno').on('keypress, keydown', function(event) {
            var $field = $(this);
            if ((event.which != 37 && (event.which != 39))
                && ((this.selectionStart < readOnlyLength_altCno)
                || ((this.selectionStart == readOnlyLength_altCno) && (event.which == 8)))) {
                return false;
            }
        });
        /*$(function() {
            $("#YOE_").daterangepicker({
                autoUpdateInput: false,
                singleDatePicker: true,
                maxDate: moment(),
                locale: {
                    format: 'YYYY-MM-DD',
                }
            });
        });*/
        $(function() {
            $("#YOE_").datepicker({
                maxDate:0,
                dateFormat: 'yy-mm-dd'
            });
        });
        function submitService () {
            $('.overlay_load').fadeIn();
            var altNUm = "";
            if(mobNoFun_($("#altCno").val()) == "91") {
                altNUm = "";
            } else {
                altNUm = mobNoFun_($("#altCno").val());
            }
            var param = {userid : localStorage.getItem("userid"),pwd : $('#current_pswd').val(),contact_person : $("#profcntctperson").attr("retname"),Primary_Contact_no :$("#pCntctNo").val(),alternateName:$("#altName").val(),primary_contact_name:$("#pCntctName").val(),alternateNo:altNUm,Drug_License_no : $("#DL_no").val(),tin : $("#TIN_no").val(),email:$("#email").val(),pincode:$("#pincode").val(),EOY:"",FinancialAssistent:"",AvgSales:"",entityId : $("#cntctpersonhidden").val()};
            $.ajax({
                data: param,
                url : 'http://'+ip+'/ThillaisServices/rest/web/WnRetailerProfile',
                type : 'POST',
                dataType: 'json',
                success: function(data) {
                    if(data.Result == 'SUCCESS') {  
                        localStorage.setItem("flashMsg","Profile details submitted successfully");
                        window.location.href = "place_order.html";    
                    } else {
                        MyError_msg(); $('.errorMsg').text('Failed to Update profile details, Please contact Admin ');
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();
                    $('.errorMsg').text(serverBusyError);$('.overlay_load').fadeOut();
                }
            });
        }
        $("#updateprofbtn").click(function(){
            if($('#cntctpersonhidden').val()){
                if($("#pCntctName").val()){
                    if($("#DL_no").val()){
                        submitService();
                    } else {
                        $("#DL_no").focus();
                        MyError_msg(); $('.errorMsg').text('Please enter Drug License No');
                    }
                } else{
                    $("#pCntctName").focus();
                    MyError_msg(); $('.errorMsg').text('Please enter Primary Contact Name');
                }
            } else{
                MyError_msg();
                $('.errorMsg').text('Please Select Retailer ');
                $('#profcntctperson').focus();
                $('.overlay_load').fadeOut();
            }
        });
    } else if(currentPName == "distributor_map") {
        $.ajax({
            data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd")},
            url : 'http://'+ip+'/ThillaisServices/rest/req/getWebUserEntity',
            type : 'POST',
            dataType: 'json',
            success: function(data) {
                if(data && data.length != 0){
                    var retailerMapTags = [];
                    $.each(data, function(index, element) {
                        if(element.a) {
                            retailerMapTags.push({
                                label: element.b.trim()+", "+element.c.trim(),
                                value: element.a
                            });
                        }
                    });
                    $("#retailerDesc").autocomplete({
                        source: retailerMapTags,
                        focus : function(event,ui) {
                            event.preventDefault();
                        },
                        select : function(event,ui) {
                            event.preventDefault();
                            $("#retailerDesc").val(ui.item.label);
                            $('#retailerDesc').attr('original_name',ui.item.label);
                            $('#retailerIdHid').val(ui.item.value);
                            $('#retailerIdHid').attr('original_hidden',ui.item.value);
                            $(".distmapping").slideUp();
                            //distributorMapServc();
                        }
                    }).bind('focus', function(){ $(this).autocomplete("search"," "); } );
                    
                    if(retailerMapTags.length == 1) {
                        $('#retailerIdHid').val(retailerMapTags[0].value);
                        $('#retailerIdHid').attr('original_hidden',retailerMapTags[0].value);
                        $("#retailerDesc").val(retailerMapTags[0].label);
                        $('#retailerDesc').attr('original_name',retailerMapTags[0].label);
                        distributorMapServc();
                    } else {
                        $("#retailerDesc").focus();
                        $('.overlay_load').fadeOut();
                    }
                } else {
                    $('.overlay_load').fadeOut();
                    MyError_msg(); $('.errorMsg').text("Dear customer, Faild to get retailer details, please try later ");
                }
            },
            error: function(xhr, status, error) {
                MyError_msg();$('.errorMsg').text(serverBusyError);
            }
        });
        $(document).on("click",".searchBtnMap",function(){
            if($("#retailerIdHid").val()) {
                distributorMapServc();
            } else {
                MyError_msg(); $('.errorMsg').text('Please Select Reatiler Name');
                $("#retailerDesc").focus();
            }
        });
        $(document).on("keyup", '#retailerDesc', function(event) {
            if($(this).attr("autocomplete")) {
                event.preventDefault();
                if($(this).attr('original_name') != $(this).val()) {
                    $(this).prev().val('');
                    $(this).prev().attr('original_hidden','');
                    $(this).attr('original_name','');
                    $(".distmapping").slideUp();
                }
            }
        });
        function distributorMapServc(){
            $('.overlay_load').fadeIn();
            $(".distmapping").hide();
            $('#Distr_map').dataTable().fnDestroy();
            $.ajax({
                data: {cid : $("#retailerIdHid").val()},
                url : 'http://'+ip+'/ThillaisServices/rest/req/getDistributorDetails',
                type : 'POST',
                dataType: 'json',
                global: true,
                success: function(data) {
                    if(data) {
                        var str = "";sno = 1;
                        $.each(data, function(index, element) {
                            str += '<tr><td>'+sno+'</td><td><input type="hidden" class="distId" value="'+element.a+'"><input type="hidden" class="distIdabbr" value="'+element.b+'"><input type="hidden" class="parentid" value="'+element.c+'"><input type="hidden" class="parentabbr" value="'+element.d+'"><input type="hidden" class="distrdescr" value="'+element.e+'">'+element.e+'</td><td>'+element.f+'</td><td><input type="hidden" class="ccodeRowHidden"><input type="text" class="form-control c_code" placeholder="Type to search Ccode" style="height:25px !important;width:100%;"></td><td class="text-center mapBtnTD"> <div class="btn btn-default btn-xs dis_mapping" title="Distributor mapping" style="width:80%;"> Map </div></td></tr>'
                            sno++;
                        });
                        $("#Distr_map > tbody").html(str);
                        $("#Distr_map").DataTable({
                            columnDefs: [
                                { width: '2%', targets: 0 },
                                { width: '20%', targets:  1},
                                { width: '35%', targets: 2 },
                                { width: '25%', targets: 3 },
                                { width: '10%', targets: 4 }
                            ],
                            "autoWidth":false
                        });
                        $(".distmapping").slideDown();
                    } else {
                        MyError_msg();$('.errorMsg').text("Dear customer, Unable to  search Distributor, please try later");
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                    $('.overlay_load').fadeOut();
                }
            });
        }
        $(document).on("focus",".c_code",function(){
            var th = $(this).parent().parent();
            $(".c_code").autocomplete({
                minLength: 2,
                source: function( request, response ) {
                    $.ajax({
                        data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),distrIdAbbr:$(".distIdabbr",th).val(),CcodeDescr:request.term},
                        url: 'http://'+ip+'/ThillaisServices/rest/req/getDistributorCcodeDetails',
                        dataType: "json",
                        type:"POST",
                        success: function(data) {
                            if(data && data.length != 0){
                                var ccodeTags = [];
                                $.each(data, function(index, element) {
                                    ccodeTags.push({
                                        value : element.a,
                                        label : element.a+" - "+element.b
                                    });
                                });
                            } else {
                                MyError_msg(); $('.errorMsg').text("Sorry, No Customer Code details found");
                            }
                            response(ccodeTags);
                        },
                        error: function(xhr, status, error) {
                            MyError_msg(); $('.errorMsg').text(serverBusyError);
                        }
                    });
                },
                focus : function(event,ui) {
                    event.preventDefault();
                },
                select: function (event, ui) {
                    event.preventDefault();
                    $(this).prev().val(ui.item.value);
                    $(this).val(ui.item.label);
                    $(this).prev().attr('original_hidden',ui.item.value);
                    $(this).attr('original_name',ui.item.label);   
                }
            });
        });
        $(document).on("click",".dis_mapping",function(){
            var th = $(this).parent().parent();
            if($("#retailerIdHid").val()) {
                if($(".ccodeRowHidden",th).val()) {
                    $('.overlay_load').fadeIn();
                    $.ajax({
                        data: {userid : localStorage.getItem("userid"),cid  : $("#retailerIdHid").val(),ccode : $(".ccodeRowHidden",th).val(),distid:$(".distId",th).val(),distAbbr:$(".distIdabbr",th).val(),parent_id:$(".parentid",th).val(),parent_dist_abbre:$(".parentabbr",th).val(),pdescr:$(".distrdescr",th).val()},
                        url : 'http://'+ip+'/ThillaisServices/rest/req/mapdistributors',
                        type : 'POST',
                        dataType: 'json',
                        global: true,
                        success: function(data) {
                            if(data.SUCCESS == 'SUCCESS') {  
                                MySuccess_msg(); $('.successMsg').text('Distributor Mapped successfully');
                                $(".c_code",th).val("").attr('disabled','disabled');
                                $(".c_code",th).val("").attr("placeholder", "Mapped");
                                $(".mapBtnTD",th).html("<b>Mapped</b> <i class='fa fa-check' style='color:#0b9444';font-size:'15px!important'></i>");
                            } else {
                                MyError_msg(); $('.errorMsg').text('Failed to Map Distributor details, Please contact Admin ');
                            }
                            $('.overlay_load').fadeOut();
                        },
                        error: function(xhr, status, error) {
                            MyError_msg();$('.errorMsg').text(serverBusyError);
                            $('.overlay_load').fadeOut();
                        }
                    });
                } else {
                    MyError_msg(); $('.errorMsg').text('Please select Customer Code');
                    $(".c_code",th).focus();
                }
            } else {
                MyError_msg(); $('.errorMsg').text('Please select Retailer Name');
                $("#retailerDesc").focus();
            }
        });
        $(".distmappop").click(function(){
            $("#dist_Ids, #dist_names, #cust_code, #address").val("");
             $("#cont_no").val("91 - ")
            $("#addDistributor").modal("show");
        });
        $('#addDistributor').on('shown.bs.modal', function () {
            $("#dist_Ids").focus();
        });
        var readOnlyLength = $('#cont_no').val().length;
        $('#cont_no').on('keypress, keydown', function(event) {
            var $field = $(this);
            if ((event.which != 37 && (event.which != 39))
                && ((this.selectionStart < readOnlyLength)
                || ((this.selectionStart == readOnlyLength) && (event.which == 8)))) {
                return false;
            }
        }); 
        $("#cont_no").keypress(function (e) {
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                MyError_msg(); $('.errorMsg').text('Please enter numerics only');
                $('#cont_no').focus();
                return false;
            }
        });
        $("#addDistSub_btn").click(function(){
            if($("#dist_Ids").val()) {
                if($("#dist_names").val()) {
                    if($("#cust_code").val()) {
                        if($('#cont_no').val().length > 5) {
                            if($("#cont_no").val().length == 15){
                                if(/^(91(\s*[\ -]\s*)?|[0]?)?[789]\d{9}$/.test($("#cont_no").val())){
                                    if($("#address").val()){
                                        $.ajax({
                                            data: {userid : localStorage.getItem("userid"),cnt_no:mobNoFun_($("#cont_no").val()),distr_id:$("#dist_Ids").val(),p_descr:$("#dist_names").val(),c_code:$("#cust_code").val(),address:$("#address").val(),status:"I"},
                                            url: 'http://'+ip+'/ThillaisServices/rest/web/WANT_DIST_ADD',
                                            dataType: "json",
                                            type:"POST",
                                            success: function(data) {
                                                if(data){
                                                    if(data.r == "s") {
                                                        MySuccess_msg(); $('.successMsg').text('Distributor Mapped successfully');
                                                        $(".mod_close").click();
                                                    } else {
                                                        MyError_msg(); $('.errorMsg').text("Dear customer, Distributor already mapped");
                                                    }
                                                } else {
                                                    MyError_msg(); $('.errorMsg').text("Dear customer, Unable to map Distributor details");
                                                }
                                            },
                                            error: function(xhr, status, error) {
                                                MyError_msg(); $('.errorMsg').text(serverBusyError);
                                            }
                                        });
                                    } else {
                                        $("#address").focus();
                                        MyError_msg(); $('.errorMsg').text('Please enter Address');
                                    }
                                } else {
                                    $("#cont_no").focus();
                                    MyError_msg(); $('.errorMsg').text('Please enter Mobile No Starting with 7 or 8 or 9');
                                }
                            } else {
                                MyError_msg();$('.errorMsg').text("Mobile Number should be 10 digits, Please enter 10 digits Mobile Number");
                                $("#cont_no").focus();
                            }
                        } else {
                            var SearchInput = $('#cont_no');
                            SearchInput.val(SearchInput.val());
                            SearchInput.focus();
                            MyError_msg();  
                            $('.errorMsg').text('Please enter Contact Number');
                            $('#cont_no').focus();                      }
                    } else {
                        MyError_msg(); $('.errorMsg').text('Please enter Customer Code');
                        $("#cust_code").focus();
                    }
                } else {
                    MyError_msg(); $('.errorMsg').text('Please enter Distributor Name');
                    $("#dist_names").focus();
                }
            } else {
                MyError_msg(); $('.errorMsg').text('Please enter TIN No');
                $("#dist_Ids").focus();
            }
        });
    } else if(currentPName == "order_details") {
        $('#fromToDate').daterangepicker({
            startDate: moment().subtract(1, 'days'),
            endDate: moment(),
            /*minDate: '01/01/2012',*/
            maxDate: moment(),
            dateLimit: {
                days: 60
            },
            showDropdowns: false,
            showWeekNumbers: false,
            timePicker: false,
            timePickerIncrement: 1,
            timePicker12Hour: false,
            ranges: {
                'Today': [moment(), moment()],
                'Today, Yesterday': [moment().subtract(1, 'days'), moment()],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                /*'This Month': [moment().startOf('month'), moment().endOf('month')],*/
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            buttonClasses: ['btn btn-default'],
            applyClass: 'btn-small btn-primary',
            cancelClass: 'btn-small',
            locale: {
                format: 'YYYY-MM-DD',
                separator: " To ",
                applyLabel: 'Submit',
                /*fromLabel: 'From',
                toLabel: 'To',*/
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                firstDay: 1
            }
        });
        $(".orderdetailsdiv").hide();
        searchServce();
        function searchServce(){
            $('.overlay_load').fadeIn();
            $('#order_DetailsTable').dataTable().fnDestroy();
            var fullDateSplit = $("#fromToDate").val().split(" To ");
            $.ajax({
                data: {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),fromDate:fullDateSplit[0],toDate:fullDateSplit[1]},
                url : 'http://'+ip+'/ThillaisServices/rest/req/getWebDistributorUserEntity',
                type : 'POST',
                dataType: 'json',
                global: true,
                success: function(data) {
                    if(data) {
                        var str = "";
                        $.each(data, function(index, element) {
                            str += '<tr call="t"><td class="searchRowPlusExp c_pointer">'+(index+1)+'</td><td class="searchRowPlusExp c_pointer"><i class="fa fa-plus-circle expandCls" style="font-size:15px !important;"></i></i></td><td class="text-center searchRowPlusExp c_pointer"><input type="hidden" class="rowIndexHidd"><input type="hidden" class="distr_id_hidden" value="'+element.c+'"><input type="hidden" class="ordernoHidden" value="'+element.a+'">'+element.a+'</td class="searchRowPlusExp c_pointer"><td class="text-center searchRowPlusExp c_pointer">'+element.b+'</td><td class="text-center searchRowPlusExp c_pointer">'+element.g+'</td><td class="searchRowPlusExp c_pointer">'+element.e+'</td><td class="searchRowPlusExp c_pointer">'+element.f+'</td><td class="searchRowPlusExp c_pointer">'+element.h+'</td><td class="searchRowPlusExp c_pointer text-center">';
                            if(element.h.length > 0) {
                                str += '<i class="fa fa-check btn btn-info btn-xs"></i>';
                            } else {
                                if(element.h == ""){
                                    str += '<i class="fa fa-times btn btn-xs" style="font-size:120%;color: #ff0000;" title="Order Still Pending"></i>';
                                }
                            }
                        });
                        $("#order_DetailsTable > tbody").html(str);
                        /*$('#order_DetailsTable tr td:not(:last-child)').addClass("searchRowClk c_pointer");
                        $('#order_DetailsTable tr td:nth-child(2)').removeClass("searchRowClk");*/
                        $("#order_DetailsTable").DataTable({
                            columnDefs: [
                                { width: '3%', targets: 0 },
                                { width: '4%', targets: 1},
                                { width: '10%', targets: 2 },
                                { width: '8%', targets: 3 },
                                { width: '10%', targets: 4 },
                                { width: '21%', targets: 5},
                                { width: '32%', targets: 6 },
                                { width: '7%', targets: 7 },
                                { width: '5%', targets: 8 }
                                
                            ],
                            "autoWidth":false,
                             "pageLength": 50
                        });
                        $(".orderdetailsdiv").slideDown();
                        dataTablePagenateIndex();
                    } else {
                        MyError_msg();$('.errorMsg').text("Dear customer, Unable to get search records, please try later");
                    }
                    $('.overlay_load').fadeOut();
                },
                error: function(xhr, status, error) {
                    MyError_msg();$('.errorMsg').text(serverBusyError);
                    $('.overlay_load').fadeOut();
                }
            });
        }
        $("#searchBtn").click(function(){
            searchServce();
        });
        
        function dataTablePagenateIndex() {
            var i = 0;
            $("#order_DetailsTable > tbody > tr").each(function(){
                if(!$(this).hasClass("subTableRow")) {
                    $(".rowIndexHidd",this).val(i);
                    i++;
                }
            });
        }
        $(document).on("click",".searchRowPlusExp",function(){
            dataTablePagenateIndex();
            var th = $(this).parent();
            var $this = $(this);
            if(th.attr("call") == "t") {
                var rowIndex = $(".rowIndexHidd",th).val();
                var param = {userid : localStorage.getItem("userid"),pwd : localStorage.getItem("pwd"),orderno:$(".ordernoHidden",th).val()}
                $('.overlay_load').fadeIn();
                $.ajax({
                    data: param,
                    url : 'http://'+ip+'/ThillaisServices/rest/req/getEntityOrderDetails',
                    type : 'POST',
                    dataType: 'json',
                    global: true,
                    success: function(data) {
                        if(data) {
                            th.attr("call","f");
                            $(".expandCls",th).removeClass("fa-plus-circle").addClass("fa-minus-circle");
                            var numCols = $("#order_DetailsTable").find('tr')[0].cells.length;
                            var i = 0;str = '<tr class="subTableRow"><td style="text-align:-webkit-center;" colspan="'+numCols+'"><div class="row" style="width:65% !important;"><table class="table subTableS"><thead><tr><th>Sno</th><th style="text-align:left !important;">Product</th><th>Product Id</th><th>Order Qty</th></tr></thead><tbody>';
                            $.each(data, function(index, element) {
                                str += '<tr><td class="text-center">'+(i+1)+'</td><td style="text-align:left !important;">'+element.c+'</td><td class="text-center">'+element.a+'</td><td class="text-center">'+element.b+'</td></tr>';
                                i++;
                            });
                            str += "</tbody></table></div></td></tr>";
                            $("#order_DetailsTable > tbody > tr").eq(rowIndex).after(str);
                            $(".subTableS").DataTable({
                                "aPaginate":false,
                                "bInfo" : false,
                                "bAutoWidth" : false
                            });
                            $(".subTableRow .dataTables_length").hide();
                        } else {
                            MyError_msg();$('.errorMsg').text("Dear customer, Unable to get search records, please try later");
                        }
                        $('.overlay_load').fadeOut();
                    },
                    error: function(xhr, status, error) {
                        MyError_msg();$('.errorMsg').text(serverBusyError);
                        $('.overlay_load').fadeOut();
                    }
                });
            }
            $("#order_DetailsTable > tbody > tr").each(function(){
                if($(this).attr("call") == "f") {
                    $(this).attr("call","t");
                    $(".expandCls",this).removeClass("fa-minus-circle").addClass("fa-plus-circle");
                }
                $(".subTableRow").remove();
            });
        });
    } 
});