

//var ip = '119.81.29.229';
var ip = '192.168.1.142:8080';
//var ip = '161.202.169.132:8080';

var newAPI_ip = "119.81.88.91/InComing-API"; //for products new API - 94 for testing, 91 for prod

var orderPagePopUpTxt1 = "Dear Customer, we have now launched *NEW WantedNote* with Many Improved Features and Convenience.";

var orderPagePopUpTxt2 = "For support issues/feedback Pls give missed call on  +91 7760718888";

var orderPageNewPopup = ""; // open - for displaying, empty - For hiding

var ourContactNumber = "91-9884470866, 91-9591360009";

var ourContactEmail = 'sales@cfshealthcare.com, support@cfshealthcare.com';

var copyRights = "Copyright © cfshealthcare.com 2016, An initiative of CFS Health Care Service Pvt Ltd.";
//15th Sept 2016
var serverDownMsg = "";

var serverBusyError = "";

var newThingInfo = 'For Better Offers and Products search, Please Login to bellow site by using same Login Credentials.<br> <b style="font-style:italic;"><a href="http://www.wantednote.com/">www.wantednote.com<a></b>';


var device_width = 700;
var NoResultsLabel = "No Results Found";
// for showing error and success messages
if (serverDownMsg.trim().length > 0) {
    $.ajaxSetup({
        beforeSend: function(jqXHR, settings) {
            $('.overlay_load').fadeOut();
            jqXHR.abort();
            MyError_msg();
            $('.errorMsg').text(serverBusyError);
        }
    });
}
//for showing error and success messages
function MyError_msg() {
    var online = navigator.onLine;
    if (online == true) {
        if (serverDownMsg.trim().length > 0) {
            serverBusyError = serverDownMsg;
        } else {
            serverBusyError = 'Server is Busy and Unable to process the request, Please try after some time';
        }
        //serverBusyError = 'Server is Busy and Unable to process the request, Please try after some time'; 
    } else if (online == false) {
        serverBusyError = 'Please check your Internet Connection, and try again.';
    }
    $('.flash-message').remove();
    $('body').append('<div id="flash" class="alert alert-danger flash-message" style="display: none"><button type="button" class="close" data-dismiss="alert" style="color:#fff !important">×</button><span id="flash_msg" class="errorMsg" style="color:#fff;"></span></div>');
    $('.flash-message').slideDown().delay(5000).fadeOut();
}

function MySuccess_msg() {
    $('.flash-message').remove();
    $('body').append('<div id="flash" class="alert alert-success flash-message" style="display: none"><button type="button" class="close" data-dismiss="alert" style="color:#fff !important">×</button><span id="flash_msg" class="successMsg"></span></div>');
    $('.flash-message').slideDown().delay(5000).fadeOut();
}
//today date
var d_f = new Date(); var dateO = d_f.getDate();
if(dateO <= 9) {  dateO =  '0'+ dateO; } else {  dateO = dateO; } var mO = d_f.getMonth() + 1; var monthO; if(mO <= 9) {  monthO =  '0' + mO; } else { monthO = mO; }
var todayDate = d_f.getFullYear()+'-'+monthO+'-'+dateO;


function ajxLoadFun(param,url,async){
    //$('.overlay_load').fadeIn();
    if(async){
        if(async == "false"){
            async = false;
        }
    } else {
        async = true;
    }
    $.ajax({
        data: param,
        url : 'http://'+ip+'/'+url,
        type : 'POST',
        dataType: 'json',
        async: async,
        global: true,
        success: function(data) {
            localStorage.setItem("rLfcX",JSON.stringify(data));
        },
        error: function(xhr, status, error) {
            localStorage.setItem("rLfcX","error");
        }
    });
    var ds = localStorage.getItem("rLfcX");
    localStorage.removeItem("rLfcX");
    return ds;
}
function currentTimeFun() {
    var d_f = new Date();
    var hours = d_f.getHours(); var hours = (hours+24)%24; var mid=' AM';
    if(hours==0){ hours=12; } else if(hours>12) {  hours=hours%12; mid=' PM'; }
    crntTimeInFun = hours + "-" + d_f.getMinutes() + "-" + d_f.getSeconds()+mid;
}
function JSONToCSVConvertor(JSONData, ReportTitle, ShowLabel) {
    var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
    var CSV = ''; 
       //console.log(JSON.stringify(arrData));
    //CSV += ReportTitle + '\r\n\n';
    var d_f = new Date();
    var hours = d_f.getHours(); var hours = (hours+24)%24; var mid=' AM';
    if(hours==0){ hours=12; } else if(hours>12) {  hours=hours%12; mid=' PM'; }
    crntTimeInFun = hours + "-" + d_f.getMinutes() + "-" + d_f.getSeconds()+mid;

    if (ShowLabel) {
        var row = "";
        for (var index in arrData[0]) {
            row += index + ',';
        }
        row = row.slice(0, -1);
        CSV += row + '\r\n';
    }
    for (var i = 0; i < arrData.length; i++) {
        var row = "";
        for (var index in arrData[i]) {
            row += '"' + arrData[i][index] + '",';
        }
        row.slice(0, row.length - 1);
        CSV += row + '\r\n';
    }
    var fileName = "";
    //var fileName = "MyReport_";
    fileName += ReportTitle.replace(/ /g,"_")+"_"+todayDate+"_"+crntTimeInFun;   
    var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
    var link = document.createElement("a");    
    link.href = uri;
    link.style = "visibility:hidden";
    link.download = fileName + ".csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
} 

//automatic dropdown open
(function($) {
    "use strict";
    $.fn.openSelect = function(){
        return this.each(function(idx,domEl) {
            if (document.createEvent) {
                var event = document.createEvent("MouseEvents");
                event.initMouseEvent("mousedown", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
                domEl.dispatchEvent(event);
            } else if (element.fireEvent) {
                domEl.fireEvent("onmousedown");
            }
        });
    }
}(jQuery));

function mobNoFun_(mob_) {
    var mob = mob_.split(" - ");
    return mob[0] + mob[1];
}

$(document).on("contextmenu",function(e){
    if(e.target.nodeName != "INPUT" && e.target.nodeName != "TEXTAREA")
         e.preventDefault();
 });