import "./styles.css";
import { useApi } from "./use-api";
import { useEffect } from "react";
import Price from "./price";
import { useRef } from "react";

export default function App() {
  const { products } = useApi();
  const totalPrice = useRef(0);
  const totalDiscountedPrice = useRef(0);
  console.log(products);
  return (
    <div className="App">
      {products
        ? products.products.map((product) => {
            totalDiscountedPrice.current = product.discounted_price
              ? totalDiscountedPrice.current + product.discounted_price
              : totalDiscountedPrice.current;
            totalPrice.current = totalPrice.current + product.price;
            return (
              <div>
                <div key={product.product_name}>{product.product_name}</div>
                <div>
                  <Price
                    price={product.price}
                    discount_price={product.discounted_price}
                  />
                </div>
              </div>
            );
          })
        : null}
      {parseFloat(totalPrice.current).toFixed(2) ? (
        <s>{parseFloat(totalPrice.current).toFixed(2)}</s>
      ) : null}
      {totalDiscountedPrice.current ? (
        <span>{parseFloat(totalDiscountedPrice.current).toFixed(2)}</span>
      ) : null}
    </div>
  );
}
