import react from "react";
import { useEffect, useState } from "react";
export const useApi = () => {
  const [products, setProducts] = useState(null);
  const productsD = async () => {
    const data = await fetch(
      "https://www.increasingly.co/Clients/Interview/products.json"
    );
    if (data.ok) {
      const response = await data.json();
      setProducts(response);
    }
  };
  useEffect(() => {
    productsD();
  }, []);
  return { products };
};
