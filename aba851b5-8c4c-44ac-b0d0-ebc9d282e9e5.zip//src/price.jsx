import React from "react";
function Price({ price, discount_price }) {
  if (discount_price) {
    return (
      <div>
        <span>${discount_price}</span>
        <s>${price}</s>
      </div>
    );
  }
  return <div>${price}</div>;
}
export default Price;
